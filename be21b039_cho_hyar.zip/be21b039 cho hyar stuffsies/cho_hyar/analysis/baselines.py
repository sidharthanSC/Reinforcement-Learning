"""
[Priority 2] Baseline comparisons.

Compares HyAR-learned medium against:
  (1) Default iCHO2291 medium      — published baseline
  (2) Single-objective FBA optimum — greedy upper bound
  (3) Random search                 — RL null hypothesis

pFBA and loopless FBA are used for validation on final states.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

import cobra
from cobra.io import read_sbml_model
from cobra.flux_analysis import pfba

from .helpers import COLORS, obj_safe, build_model_with_learned_medium


def _eval_model(model: cobra.Model, objective: str) -> dict:
    """Run FBA + pFBA on model; return scalar metrics."""
    model.objective = objective
    sol = model.optimize()
    try:
        psol = pfba(model)
        pfba_obj = float(psol[objective]); sum_abs = float(np.abs(psol.fluxes).sum())
    except Exception:
        pfba_obj = np.nan; sum_abs = np.nan
    return {
        "fba_obj":  float(sol[objective]) if sol.status == "optimal" else np.nan,
        "pfba_obj": pfba_obj,
        "pfba_sum_abs_flux": sum_abs,
        "status": sol.status,
    }


def default_medium_baseline(xml_path: str, objective: str) -> dict:
    m = read_sbml_model(xml_path)
    max_bio = float(m.optimize()["biomass_cho"])
    m.reactions.get_by_id("biomass_cho").lower_bound = max_bio
    m.reactions.get_by_id("biomass_cho").upper_bound = max_bio
    return {"baseline": "default_medium", **_eval_model(m, objective)}


def fba_max_baseline(xml_path: str, objective: str) -> dict:
    """Unrestricted bounds → FBA upper bound."""
    m = read_sbml_model(xml_path)
    max_bio = float(m.optimize()["biomass_cho"])
    for r in list(m.medium.keys()):
        m.reactions.get_by_id(r).lower_bound = -1000
        m.reactions.get_by_id(r).upper_bound = 1000
    m.reactions.get_by_id("biomass_cho").lower_bound = max_bio
    m.reactions.get_by_id("biomass_cho").upper_bound = max_bio
    return {"baseline": "fba_unrestricted", **_eval_model(m, objective)}


def random_search_baseline(xml_path: str, objective: str,
                           media: list, n_trials: int = 50,
                           seed: int = 0) -> dict:
    """Random medium compositions; report best."""
    rng = np.random.RandomState(seed)
    m = read_sbml_model(xml_path)
    max_bio = float(m.optimize()["biomass_cho"])

    best = -np.inf
    for _ in range(n_trials):
        for r in media:
            rxn = m.reactions.get_by_id(r)
            if rng.rand() > 0.5:
                rxn.lower_bound = float(rng.uniform(-10, 0))
                rxn.upper_bound = 0.0
            else:
                rxn.lower_bound = 0.0; rxn.upper_bound = 0.0
        m.reactions.get_by_id("biomass_cho").lower_bound = max_bio
        m.reactions.get_by_id("biomass_cho").upper_bound = max_bio
        m.objective = objective
        sol = m.optimize()
        if sol.status == "optimal" and float(sol[objective]) > best:
            best = float(sol[objective])
    return {"baseline": f"random_{n_trials}", "fba_obj": best,
            "pfba_obj": np.nan, "pfba_sum_abs_flux": np.nan,
            "status": "optimal" if np.isfinite(best) else "failed"}


def hyar_baseline(xml_path: str, history: dict) -> dict:
    obj = history["objective"]
    m, _ = build_model_with_learned_medium(
        xml_path, obj, history["media"],
        history["final_state"], history["final_discrete"])
    return {"baseline": "HyAR", **_eval_model(m, obj)}


def run_all(xml_path: str, histories: list, out_dir: Path,
            n_random: int = 50):
    rows = []
    for h in histories:
        obj = h["objective"]
        print(f"  [baselines] {obj}")
        media = h["media"]
        for fn in [default_medium_baseline, fba_max_baseline]:
            rec = fn(xml_path, obj); rec["objective"] = obj
            rows.append(rec)
        rec = random_search_baseline(xml_path, obj, media, n_random)
        rec["objective"] = obj; rows.append(rec)
        rec = hyar_baseline(xml_path, h); rec["objective"] = obj
        rows.append(rec)

    df = pd.DataFrame(rows)
    df.to_csv(out_dir / "baselines.csv", index=False)

    # Bar chart — FBA obj per (objective, baseline)
    fig, ax = plt.subplots(figsize=(11, 6), dpi=130)
    pivot = df.pivot(index="baseline", columns="objective", values="fba_obj")
    order = ["default_medium", "fba_unrestricted", f"random_{n_random}", "HyAR"]
    pivot = pivot.reindex([o for o in order if o in pivot.index])
    pivot.plot(kind="bar", ax=ax,
               color=[COLORS.get(c, "grey") for c in pivot.columns])
    ax.set_ylabel("FBA objective"); ax.set_title("Baseline comparison")
    ax.legend(title="Objective", bbox_to_anchor=(1.02, 1))
    plt.xticks(rotation=15); plt.tight_layout()
    plt.savefig(out_dir / "baselines_bar.png")
    plt.close()
    return df
