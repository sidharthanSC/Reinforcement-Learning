"""Basic per-objective training plots."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from .helpers import COLORS, MARKERS, obj_safe


def plot_reward_curves(history: dict, out_dir: Path, patience: int):
    obj = history["objective"]
    rew = history["raw_reward"]
    shaped = history["reward"]
    opt = history["optimal_flux"]
    pct = [100 * r / opt if opt != 0 else 0 for r in rew]
    conv_x = max(len(rew) - patience, 0)

    fig, axes = plt.subplots(1, 3, figsize=(18, 5), dpi=130)

    axes[0].plot(rew, color=COLORS[obj], lw=1.2)
    if len(rew) >= 10:
        ma = pd.Series(rew).rolling(10).mean()
        axes[0].plot(ma, color="black", lw=1.5, alpha=0.6, label="MA(10)")
    axes[0].axvline(conv_x, color="red", linestyle="--", alpha=0.7)
    axes[0].set_xlabel("Step"); axes[0].set_ylabel(f"Raw FBA flux ({obj})")
    axes[0].set_title(f"Raw reward – {obj}"); axes[0].legend()

    axes[1].plot(shaped, color=COLORS[obj], lw=1.2)
    axes[1].axvline(conv_x, color="red", linestyle="--", alpha=0.7)
    axes[1].set_xlabel("Step"); axes[1].set_ylabel("Shaped reward")
    axes[1].set_title("Shaped reward (with normalization + PBRS + penalties)")

    axes[2].plot(pct, color=COLORS[obj], lw=1.2)
    axes[2].axvline(conv_x, color="red", linestyle="--", alpha=0.7)
    axes[2].set_xlabel("Step"); axes[2].set_ylabel("% of optimal flux")
    axes[2].set_title(f"% of optimal – {obj}")

    plt.tight_layout()
    plt.savefig(out_dir / f"reward_curves_{obj_safe(obj)}.png")
    plt.close()


def plot_state_trajectory(history: dict, out_dir: Path, patience: int):
    obj = history["objective"]
    states = np.array(history["state"])
    media = history["media"]
    conv_x = max(len(states) - patience, 0)

    plt.figure(figsize=(12, 6), dpi=130)
    for i, r in enumerate(media):
        plt.plot(states[:, i], label=r, alpha=0.7, lw=0.8)
    plt.axvline(conv_x, color="red", linestyle="--", alpha=0.7)
    plt.xlabel("Step"); plt.ylabel("Uptake rate lower bound")
    plt.title(f"State trajectory – {obj}")
    plt.legend(bbox_to_anchor=(1.01, 1), fontsize=6)
    plt.tight_layout()
    plt.savefig(out_dir / f"state_trajectory_{obj_safe(obj)}.png")
    plt.close()


def plot_discrete_heatmap(history: dict, out_dir: Path):
    obj = history["objective"]
    disc = np.array(history["discrete"])
    media = history["media"]
    plt.figure(figsize=(14, max(4, len(media)*0.25)), dpi=130)
    sns.heatmap(disc.T, cmap="Blues", cbar=True,
                yticklabels=media, xticklabels=False)
    plt.xlabel("Step"); plt.ylabel("Exchange reaction")
    plt.title(f"Discrete (add/remove) heatmap – {obj}")
    plt.tight_layout()
    plt.savefig(out_dir / f"discrete_heatmap_{obj_safe(obj)}.png")
    plt.close()


def plot_key_fluxes(history: dict, out_dir: Path):
    """Plot all 5 tracked fluxes (biomass + 4 IgG objectives) over time."""
    obj = history["objective"]
    kf = history["key_fluxes"]
    if not kf: return
    df = pd.DataFrame(kf)
    fig, ax = plt.subplots(figsize=(12, 5), dpi=130)
    for col in df.columns:
        ax.plot(df[col], label=col, lw=1.0, alpha=0.8)
    ax.set_xlabel("Step"); ax.set_ylabel("Flux")
    ax.set_title(f"Key fluxes trajectory – {obj}")
    ax.legend(bbox_to_anchor=(1.01, 1), fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / f"key_fluxes_{obj_safe(obj)}.png")
    plt.close()
