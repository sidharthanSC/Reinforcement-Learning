"""
[Priority 10] Hierarchical clustering + Jaccard similarity across objectives.

Two complementary views:
  (a) Clustermap of reactions × objectives by uptake rate
  (b) Jaccard similarity between the "active reaction" sets of each pair
      of objectives
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from .helpers import COLORS, obj_safe


def hierarchical_cluster(histories: list, out_dir: Path):
    # Build K × n_obj matrix of final uptake rates
    records = {}
    for h in histories:
        records[h["objective"]] = pd.Series(
            {h["media"][i]: h["final_state"][i] for i in range(len(h["media"]))})
    df = pd.DataFrame(records).fillna(0)

    # Z-score rows for better cluster visibility
    df_z = df.sub(df.mean(axis=1), axis=0).div(df.std(axis=1).replace(0, 1), axis=0)

    cg = sns.clustermap(df_z, method="ward", cmap="RdBu_r", center=0,
                         figsize=(8, max(6, len(df)*0.25)),
                         cbar_pos=(0.02, 0.85, 0.03, 0.1),
                         dendrogram_ratio=(0.18, 0.12),
                         linewidths=0.3)
    cg.ax_heatmap.set_title("Hierarchical clustering of reactions × objectives\n"
                             "(row-z-scored final uptake rate)",
                             pad=12)
    plt.savefig(out_dir / "hierarchical_clustermap.png", dpi=130,
                bbox_inches="tight")
    plt.close()


def jaccard_active_sets(histories: list, out_dir: Path, eps: float = 1e-6):
    sets = {}
    for h in histories:
        active = {h["media"][i] for i in range(len(h["media"]))
                  if h["final_discrete"][i] == 1
                  and abs(h["final_state"][i]) > eps}
        sets[h["objective"]] = active

    objs = list(sets.keys()); n = len(objs)
    J = np.zeros((n, n))
    for i, a in enumerate(objs):
        for j, b in enumerate(objs):
            u = sets[a] | sets[b]
            J[i, j] = len(sets[a] & sets[b]) / len(u) if u else 0
    Jdf = pd.DataFrame(J, index=objs, columns=objs)
    Jdf.to_csv(out_dir / "jaccard_active_sets.csv")

    fig, ax = plt.subplots(figsize=(6, 5), dpi=130)
    sns.heatmap(Jdf, annot=True, fmt=".2f", cmap="YlGnBu", ax=ax,
                vmin=0, vmax=1)
    ax.set_title("Jaccard similarity of active-reaction sets\n(learned medium)")
    plt.tight_layout()
    plt.savefig(out_dir / "jaccard_active_sets.png")
    plt.close()

    # Pairwise overlap summary
    rows = []
    for i in range(n):
        for j in range(i+1, n):
            a, b = objs[i], objs[j]
            rows.append({
                "obj_a": a, "obj_b": b,
                "intersection": len(sets[a] & sets[b]),
                "union":        len(sets[a] | sets[b]),
                "a_only":       len(sets[a] - sets[b]),
                "b_only":       len(sets[b] - sets[a]),
                "jaccard":      float(J[i, j]),
            })
    pd.DataFrame(rows).to_csv(out_dir / "jaccard_pairwise.csv", index=False)


def run_all(histories: list, out_dir: Path):
    hierarchical_cluster(histories, out_dir)
    jaccard_active_sets(histories, out_dir)
