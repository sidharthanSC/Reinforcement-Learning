"""
[Priority 9] Convergence diagnostics.

Three complementary views:
  (a) Episodic return with rolling mean ± std
  (b) Discrete-action entropy over a sliding window
      (exploration → exploitation diagnostic)
  (c) Action-repeat / toggle rate per episode
      (converged policies should drive this < 5%)
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .helpers import COLORS, obj_safe


def _discrete_entropy(disc: np.ndarray, window: int) -> np.ndarray:
    """Entropy of per-reaction add/remove distribution over a sliding window."""
    T, K = disc.shape
    H = np.zeros(T)
    for t in range(T):
        lo = max(0, t - window + 1)
        w = disc[lo:t + 1]
        if w.shape[0] < 2:
            H[t] = 0; continue
        p = w.mean(axis=0)                   # P(on) per reaction
        p = np.clip(p, 1e-9, 1 - 1e-9)
        h_per_rxn = -(p * np.log(p) + (1 - p) * np.log(1 - p))
        H[t] = h_per_rxn.mean()              # mean entropy across K reactions
    return H


def _toggle_rate(disc: np.ndarray, window: int) -> np.ndarray:
    T, K = disc.shape
    rates = np.zeros(T)
    for t in range(1, T):
        lo = max(0, t - window + 1)
        w = disc[lo:t + 1]
        if w.shape[0] < 2: continue
        diffs = np.abs(np.diff(w, axis=0)).sum()
        rates[t] = diffs / ((w.shape[0] - 1) * K)
    return rates


def run_for_objective(history: dict, out_dir: Path, window: int = 20):
    obj = history["objective"]
    disc = np.array(history["discrete"])
    reward = np.array(history["raw_reward"])
    T = len(reward)

    rolling_mean = pd.Series(reward).rolling(window).mean()
    rolling_std  = pd.Series(reward).rolling(window).std()

    H = _discrete_entropy(disc, window)
    tog = _toggle_rate(disc, window)

    fig, axes = plt.subplots(3, 1, figsize=(11, 9), dpi=130, sharex=True)
    axes[0].plot(reward, color=COLORS[obj], alpha=0.4, lw=0.7, label="Raw reward")
    axes[0].plot(rolling_mean, color="black", lw=1.6, label=f"MA({window})")
    axes[0].fill_between(np.arange(T),
                          rolling_mean - rolling_std,
                          rolling_mean + rolling_std,
                          color="grey", alpha=0.3, label="±1σ")
    axes[0].set_ylabel(f"Raw flux ({obj})"); axes[0].legend(fontsize=8)
    axes[0].set_title(f"Convergence diagnostics – {obj}")

    axes[1].plot(H, color="darkorange", lw=1.4)
    axes[1].set_ylabel(f"Discrete entropy\n(window={window})")
    axes[1].axhline(0, color="grey", lw=0.5)

    axes[2].plot(tog, color="steelblue", lw=1.4)
    axes[2].axhline(0.05, color="red", linestyle="--", lw=1,
                    label="5% threshold")
    axes[2].set_ylabel(f"Toggle rate\n(window={window})")
    axes[2].set_xlabel("Step"); axes[2].legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / f"convergence_{obj_safe(obj)}.png")
    plt.close()

    # final summary
    summary = {
        "objective": obj, "total_steps": T,
        "mean_reward_last_20%": float(np.nanmean(reward[int(0.8*T):])),
        "std_reward_last_20%":  float(np.nanstd(reward[int(0.8*T):])),
        "final_entropy":   float(H[-1]),
        "final_toggle_rate": float(tog[-1]),
        "converged_by_toggle": bool(tog[-1] < 0.05),
    }
    return summary


def run_all(histories: list, out_dir: Path, window: int = 20):
    rows = [run_for_objective(h, out_dir, window) for h in histories]
    pd.DataFrame(rows).to_csv(out_dir / "convergence_summary.csv", index=False)
