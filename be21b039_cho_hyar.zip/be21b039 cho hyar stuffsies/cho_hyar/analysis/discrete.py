"""Discrete-action (add/remove) analysis — from v1, consolidated."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from .helpers import COLORS, obj_safe


def _events(disc: np.ndarray, media: list) -> pd.DataFrame:
    T, K = disc.shape
    rows = []
    for t in range(1, T):
        for ki in range(K):
            prev, curr = disc[t-1, ki], disc[t, ki]
            if prev == 0 and curr == 1:
                rows.append({"step": t, "reaction": media[ki], "event": "ADD"})
            elif prev == 1 and curr == 0:
                rows.append({"step": t, "reaction": media[ki], "event": "REMOVE"})
    return pd.DataFrame(rows) if rows else pd.DataFrame(columns=["step","reaction","event"])


def _stats(disc: np.ndarray, media: list) -> pd.DataFrame:
    T, K = disc.shape
    rows = []
    for ki, rxn in enumerate(media):
        col = disc[:, ki]
        adds = sum(1 for t in range(1, T) if col[t-1] == 0 and col[t] == 1)
        removes = sum(1 for t in range(1, T) if col[t-1] == 1 and col[t] == 0)
        first_add = int(np.argmax(col == 1)) if col.any() else None
        rem_idx = np.where((col[:-1] == 1) & (col[1:] == 0))[0]
        last_rem = int(rem_idx[-1]) + 1 if len(rem_idx) else None
        rows.append({
            "reaction": rxn, "active_steps": int(col.sum()),
            "active_pct": round(100*col.mean(), 1),
            "n_adds": adds, "n_removes": removes, "n_toggles": adds+removes,
            "first_added_step": first_add, "last_removed_step": last_rem,
            "final_state": int(col[-1])
        })
    return pd.DataFrame(rows).set_index("reaction")


def per_objective(history: dict, out_dir: Path):
    obj = history["objective"]
    disc = np.array(history["discrete"])
    media = history["media"]
    stats = _stats(disc, media)
    stats.to_csv(out_dir / f"discrete_stats_{obj_safe(obj)}.csv")

    # ── Toggle counts (diverging bars) ───────────────────────────────────
    s = stats.sort_values("n_toggles", ascending=False)
    fig, ax = plt.subplots(figsize=(10, max(4, len(media)*0.3)), dpi=130)
    ax.barh(s.index, s["n_adds"],    color="seagreen", label="ADD", alpha=0.85)
    ax.barh(s.index, -s["n_removes"], color="crimson", label="REMOVE", alpha=0.85)
    ax.axvline(0, color="black", lw=0.8)
    ax.set_xlabel("← Removes | Adds →"); ax.set_title(f"Toggle counts – {obj}")
    ax.legend(); plt.tight_layout()
    plt.savefig(out_dir / f"toggle_counts_{obj_safe(obj)}.png")
    plt.close()

    # ── Activity bar ─────────────────────────────────────────────────────
    colors = ["seagreen" if v==1 else "crimson" for v in stats["final_state"]]
    fig, ax = plt.subplots(figsize=(8, max(4, len(media)*0.3)), dpi=130)
    bars = ax.barh(stats.index, stats["active_pct"], color=colors, alpha=0.85)
    ax.bar_label(bars, fmt="%.0f%%", fontsize=7)
    ax.set_xlabel("% steps active")
    ax.set_title(f"Activity % – {obj}\n(green=kept at end, red=removed)")
    ax.set_xlim(0, 115); plt.tight_layout()
    plt.savefig(out_dir / f"activity_bar_{obj_safe(obj)}.png")
    plt.close()

    # ── Add/remove timeline ───────────────────────────────────────────────
    events = _events(disc, media)
    if not events.empty:
        palette = {"ADD": "seagreen", "REMOVE": "crimson"}
        fig, ax = plt.subplots(figsize=(14, max(4, len(media)*0.3)), dpi=130)
        for evt, grp in events.groupby("event"):
            ax.scatter(grp["step"], grp["reaction"],
                       color=palette[evt],
                       marker=("^" if evt=="ADD" else "v"),
                       s=50, label=evt, alpha=0.85, zorder=3)
        for i in range(len(media)):
            if i%2==0: ax.axhspan(i-0.5, i+0.5, color="lightgrey", alpha=0.3, zorder=0)
        ax.set_xlabel("Step"); ax.set_ylabel("Reaction")
        ax.set_title(f"Add/remove timeline – {obj}")
        ax.set_yticks(range(len(media))); ax.set_yticklabels(media, fontsize=7)
        ax.legend(); plt.tight_layout()
        plt.savefig(out_dir / f"add_remove_timeline_{obj_safe(obj)}.png")
        plt.close()

    # ── Reward vs active count ────────────────────────────────────────────
    reward = np.array(history["raw_reward"])
    n_active = disc.sum(axis=1)
    fig, ax = plt.subplots(figsize=(8, 5), dpi=130)
    sc = ax.scatter(n_active, reward, c=np.arange(len(reward)),
                    cmap="viridis", alpha=0.7, s=25)
    plt.colorbar(sc, ax=ax, label="Step")
    df_tmp = pd.DataFrame({"n": n_active, "r": reward})
    means = df_tmp.groupby("n")["r"].mean()
    ax.plot(means.index, means.values, "r-o", lw=2, ms=4, label="Mean")
    ax.set_xlabel("# active reactions"); ax.set_ylabel(f"Raw flux ({obj})")
    ax.set_title(f"Reward vs active count – {obj}"); ax.legend()
    plt.tight_layout()
    plt.savefig(out_dir / f"reward_vs_active_{obj_safe(obj)}.png")
    plt.close()


def cross_objective(histories: list, out_dir: Path):
    # Activity % heatmap
    records = {}
    for h in histories:
        records[h["objective"]] = _stats(np.array(h["discrete"]),
                                          h["media"])["active_pct"]
    df = pd.DataFrame(records)
    df = df.loc[df.mean(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots(figsize=(8, max(5, len(df)*0.3)), dpi=130)
    sns.heatmap(df, annot=True, fmt=".0f", cmap="RdYlGn",
                linewidths=0.4, vmin=0, vmax=100, ax=ax,
                cbar_kws={"label": "% active"})
    ax.set_title("Activity % across objectives")
    plt.tight_layout()
    plt.savefig(out_dir / "xobj_activity_heatmap.png")
    plt.close()
    df.to_csv(out_dir / "xobj_activity.csv")

    # Final-state binary heatmap
    fs = {h["objective"]:
          _stats(np.array(h["discrete"]), h["media"])["final_state"]
          for h in histories}
    fs_df = pd.DataFrame(fs)
    fs_df = fs_df.loc[fs_df.sum(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots(figsize=(7, max(5, len(fs_df)*0.3)), dpi=130)
    sns.heatmap(fs_df, annot=True, fmt="d", cmap="RdYlGn",
                linewidths=0.4, vmin=0, vmax=1, ax=ax)
    ax.set_title("Final active/removed at convergence")
    plt.tight_layout()
    plt.savefig(out_dir / "xobj_final_state_heatmap.png")
    plt.close()
    fs_df.to_csv(out_dir / "xobj_final_state.csv")

    return df, fs_df
