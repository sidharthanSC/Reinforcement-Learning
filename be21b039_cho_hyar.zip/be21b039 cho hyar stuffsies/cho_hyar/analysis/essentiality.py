"""
[Priority 8] Single-reaction essentiality at the learned state.

Knocks out every reaction and checks whether the IgG objective drops below
1% of its original value. Produces per-objective essentiality tables and a
cross-objective union/intersection matrix.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from .helpers import COLORS, obj_safe, build_model_with_learned_medium


def run_for_objective(xml_path: str, history: dict, out_dir: Path,
                      threshold: float = 0.01,
                      restrict_to: str = "exchanges") -> pd.DataFrame:
    obj = history["objective"]
    print(f"  [essentiality] {obj}  (threshold={threshold*100:.0f}% of optimal)")
    m, _ = build_model_with_learned_medium(
        xml_path, obj, history["media"],
        history["final_state"], history["final_discrete"])
    try:
        base = float(m.optimize()[obj])
    except Exception:
        return pd.DataFrame()

    if base <= 0:
        print(f"    baseline objective non-positive ({base:.3g}); skipping")
        return pd.DataFrame()

    target = threshold * base
    rxns = ([r for r in m.reactions if r.boundary]
            if restrict_to == "exchanges" else list(m.reactions))

    rows = []
    for r in rxns:
        lb, ub = r.lower_bound, r.upper_bound
        r.lower_bound = 0.0; r.upper_bound = 0.0
        try:
            sol = m.optimize()
            val = float(sol[obj]) if sol.status == "optimal" else 0.0
        except Exception:
            val = 0.0
        r.lower_bound, r.upper_bound = lb, ub
        rows.append({
            "reaction": r.id, "ko_obj": val,
            "base_obj": base, "fraction_retained": val / base,
            "essential": val < target,
        })
    df = pd.DataFrame(rows).set_index("reaction")
    df["objective"] = obj
    df.to_csv(out_dir / f"essentiality_{obj_safe(obj)}.csv")
    return df


def run_all(xml_path: str, histories: list, out_dir: Path,
            threshold: float = 0.01):
    dfs = {}
    for h in histories:
        dfs[h["objective"]] = run_for_objective(xml_path, h, out_dir, threshold)

    # ── cross-objective essentiality matrix ────────────────────────────────
    if dfs and all(not d.empty for d in dfs.values()):
        ess = pd.DataFrame({o: d["essential"].astype(int) for o, d in dfs.items()})
        ess = ess.fillna(0).astype(int)
        # keep only reactions essential in at least one objective
        ess = ess.loc[ess.sum(axis=1) > 0]
        ess = ess.loc[ess.sum(axis=1).sort_values(ascending=False).index]
        ess.to_csv(out_dir / "essentiality_matrix.csv")

        if len(ess):
            fig, ax = plt.subplots(figsize=(8, max(5, len(ess)*0.25)), dpi=130)
            sns.heatmap(ess, annot=True, fmt="d", cmap="Reds",
                        linewidths=0.4, vmin=0, vmax=1, ax=ax,
                        cbar_kws={"label": "Essential (1) / Dispensable (0)"})
            ax.set_title("Cross-objective reaction essentiality")
            plt.tight_layout()
            plt.savefig(out_dir / "essentiality_matrix.png")
            plt.close()

            # summary: universal vs objective-specific
            universal = ess.index[ess.sum(axis=1) == ess.shape[1]].tolist()
            unique = {o: ess.index[(ess[o] == 1) & (ess.sum(axis=1) == 1)].tolist()
                      for o in ess.columns}
            with open(out_dir / "essentiality_summary.txt", "w") as f:
                f.write(f"Universally essential ({len(universal)}):\n")
                for r in universal: f.write(f"  {r}\n")
                for o, rs in unique.items():
                    f.write(f"\nObjective-specific essential ({o}, {len(rs)}):\n")
                    for r in rs: f.write(f"  {r}\n")
    return dfs
