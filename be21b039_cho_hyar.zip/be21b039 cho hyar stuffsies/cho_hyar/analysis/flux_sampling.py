"""
[Priority 3] Flux sampling (ACHR / optgp) on the learned medium.

Provides a distribution of feasible fluxes for each of the 4 IgG objectives
rather than a single FBA point.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from cobra.sampling import sample

from .helpers import COLORS, obj_safe, build_model_with_learned_medium


def run_sampling(xml_path: str, history: dict, out_dir: Path,
                 n_samples: int = 5_000, method: str = "optgp") -> pd.DataFrame:
    obj = history["objective"]
    print(f"  [flux sampling] {obj}  method={method}, n={n_samples}")
    model, _ = build_model_with_learned_medium(
        xml_path, obj, history["media"],
        history["final_state"], history["final_discrete"])
    try:
        samples = sample(model, n=n_samples, method=method,
                         thinning=10, processes=1)
    except Exception as e:
        print(f"    sampling failed: {e}")
        return pd.DataFrame()
    samples.to_csv(out_dir / f"flux_samples_{obj_safe(obj)}.csv", index=False)
    return samples


def plot_objective_distributions(sample_dfs: dict, out_dir: Path):
    """Violin plot of all 4 IgG objectives across all runs."""
    rows = []
    targets = ["igg_formation", "igg_hc", "igg_lc", "DM_igg[g]"]
    for run_obj, s in sample_dfs.items():
        if s.empty: continue
        for t in targets:
            if t in s.columns:
                for v in s[t].values:
                    rows.append({"run_obj": run_obj, "target": t, "flux": v})
    if not rows: return
    df = pd.DataFrame(rows)

    fig, ax = plt.subplots(figsize=(14, 6), dpi=130)
    sns.violinplot(data=df, x="target", y="flux", hue="run_obj",
                   palette={k: v for k, v in COLORS.items()
                            if k in df["run_obj"].unique()},
                   ax=ax, cut=0, inner="quartile")
    ax.set_title("Flux sample distributions for each IgG objective "
                 "under each learned medium")
    ax.set_xlabel("IgG objective (target)"); ax.set_ylabel("Flux (sampled)")
    plt.tight_layout()
    plt.savefig(out_dir / "flux_sampling_violins.png")
    plt.close()


def run_all(xml_path: str, histories: list, out_dir: Path, n_samples: int):
    dfs = {}
    for h in histories:
        s = run_sampling(xml_path, h, out_dir, n_samples)
        dfs[h["objective"]] = s
    plot_objective_distributions(dfs, out_dir)
    return dfs
