"""
[Priority 1] Flux Variability Analysis at the learned state.

For every reaction, computes min/max flux at fraction_of_optimum=0.9 with
loopless=True and plots cross-objective comparison.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from cobra.flux_analysis import flux_variability_analysis

from .helpers import obj_safe, build_model_with_learned_medium, COLORS


def run_fva_for_objective(xml_path: str, history: dict,
                          out_dir: Path,
                          fraction: float = 0.9,
                          loopless: bool = True,
                          restrict_to: str = "exchanges") -> pd.DataFrame:
    """
    restrict_to:
      'exchanges' — only boundary reactions (fast, ~seconds)
      'all'       — all reactions (minutes on iCHO2291)
    """
    obj = history["objective"]
    print(f"  [FVA] {obj}  (fraction={fraction}, loopless={loopless}, scope={restrict_to})")
    model, _ = build_model_with_learned_medium(
        xml_path, obj, history["media"],
        history["final_state"], history["final_discrete"])

    if restrict_to == "exchanges":
        rxns = [r for r in model.reactions if r.boundary]
    else:
        rxns = list(model.reactions)

    try:
        fva = flux_variability_analysis(model, reaction_list=rxns,
                                         fraction_of_optimum=fraction,
                                         loopless=loopless,
                                         processes=1)
    except Exception as e:
        print(f"    FVA failed: {e}")
        return pd.DataFrame()

    fva["range"] = fva["maximum"] - fva["minimum"]
    fva["reaction"] = fva.index
    fva["objective"] = obj
    fva.to_csv(out_dir / f"fva_{obj_safe(obj)}.csv")
    return fva


def plot_fva_summary(fva_dfs: list, out_dir: Path, top_n: int = 30):
    """Boxplot of |range| per objective; top-N most variable reactions."""
    if not fva_dfs: return
    combined = pd.concat(fva_dfs, ignore_index=True)

    # Top-N variable reactions pooled
    mean_range = (combined.groupby("reaction")["range"]
                  .mean()
                  .sort_values(ascending=False)
                  .head(top_n))
    sub = combined[combined["reaction"].isin(mean_range.index)]
    sub = sub.assign(rxn=sub["reaction"])

    fig, ax = plt.subplots(figsize=(12, max(6, top_n*0.25)), dpi=130)
    sns.barplot(data=sub, y="rxn", x="range", hue="objective",
                palette={k: v for k, v in COLORS.items()
                         if k in sub["objective"].unique()},
                ax=ax, order=mean_range.index)
    ax.set_xlabel("FVA range (max - min)")
    ax.set_title(f"FVA range – top {top_n} most-variable reactions")
    plt.tight_layout()
    plt.savefig(out_dir / "fva_top_variable.png")
    plt.close()

    # Pinned (low-range) reactions — tight flux requirement
    pinned = (combined.groupby("reaction")["range"]
              .mean().sort_values().head(top_n))
    sub2 = combined[combined["reaction"].isin(pinned.index)]
    fig, ax = plt.subplots(figsize=(12, max(6, top_n*0.25)), dpi=130)
    sns.barplot(data=sub2, y="reaction", x="range", hue="objective",
                palette={k: v for k, v in COLORS.items()
                         if k in sub2["objective"].unique()},
                ax=ax, order=pinned.index)
    ax.set_xlabel("FVA range")
    ax.set_title(f"FVA – top {top_n} most-pinned (tightly required) reactions")
    plt.tight_layout()
    plt.savefig(out_dir / "fva_top_pinned.png")
    plt.close()

    # Jaccard across objectives on "non-blocked" set (|range|>1e-6)
    nonblocked = {o: set(combined[(combined["objective"]==o) & (combined["range"]>1e-6)]
                          ["reaction"])
                  for o in combined["objective"].unique()}
    objs = list(nonblocked.keys())
    J = np.zeros((len(objs), len(objs)))
    for i, o1 in enumerate(objs):
        for j, o2 in enumerate(objs):
            u = nonblocked[o1] | nonblocked[o2]
            J[i, j] = len(nonblocked[o1] & nonblocked[o2]) / len(u) if u else 0
    fig, ax = plt.subplots(figsize=(6, 5), dpi=130)
    sns.heatmap(pd.DataFrame(J, index=objs, columns=objs),
                annot=True, fmt=".2f", cmap="YlGnBu", ax=ax)
    ax.set_title("Jaccard similarity: non-blocked reaction sets")
    plt.tight_layout()
    plt.savefig(out_dir / "fva_jaccard.png")
    plt.close()


def run_all(xml_path: str, histories: list, out_dir: Path):
    fva_dfs = []
    for h in histories:
        df = run_fva_for_objective(xml_path, h, out_dir)
        if not df.empty: fva_dfs.append(df)
    plot_fva_summary(fva_dfs, out_dir)
    return fva_dfs
