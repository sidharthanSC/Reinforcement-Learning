"""Shared helpers for all analysis modules."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import cobra
from cobra.io import read_sbml_model


COLORS = {
    "igg_formation": "crimson",
    "igg_hc":        "dodgerblue",
    "igg_lc":        "forestgreen",
    "DM_igg[g]":     "purple",
}
MARKERS = {
    "igg_formation": "s",
    "igg_hc":        "D",
    "igg_lc":        "o",
    "DM_igg[g]":     "^",
}


def obj_safe(objective: str) -> str:
    return objective.replace("[", "_").replace("]", "_")


def load_history(out_dir: Path, objective: str) -> dict:
    path = out_dir / f"history_{obj_safe(objective)}.json"
    with open(path) as f:
        return json.load(f)


def build_model_with_learned_medium(xml_path: str, objective: str,
                                     media_ids: list, final_state: list,
                                     final_discrete: list,
                                     max_biomass: float = None) -> cobra.Model:
    """
    Rebuild a cobra model with the learned medium applied.
    final_state and final_discrete are lists of length K.
    Deactivated reactions get (0, 0) bounds.
    """
    m = read_sbml_model(xml_path)
    if max_biomass is None:
        d = read_sbml_model(xml_path)
        max_biomass = float(d.optimize()["biomass_cho"])
    m.reactions.get_by_id("biomass_cho").lower_bound = max_biomass
    m.reactions.get_by_id("biomass_cho").upper_bound = max_biomass
    m.objective = objective

    for i, rxn_id in enumerate(media_ids):
        rxn = m.reactions.get_by_id(rxn_id)
        if final_discrete[i] == 1:
            lb = float(final_state[i])
            rxn.lower_bound = lb
            # keep upper bound from original (0 for exchanges)
        else:
            rxn.lower_bound = 0.0
            rxn.upper_bound = 0.0
    return m, max_biomass
