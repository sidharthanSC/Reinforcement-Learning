"""
[Priority 4] Pareto frontier analysis with hypervolume.

Evaluates each HyAR-learned medium on ALL 4 objectives simultaneously and
identifies the Pareto-dominant subset.  Hypervolume computed against a
reference point at the minimum of all evaluated points.
"""
from __future__ import annotations
from pathlib import Path
from itertools import combinations
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .helpers import COLORS, MARKERS, obj_safe, build_model_with_learned_medium
from cobra.io import read_sbml_model


TARGET_OBJS = ["igg_formation", "igg_hc", "igg_lc", "DM_igg[g]"]


def _eval_all_objectives(xml_path: str, history: dict) -> dict:
    """Apply learned medium from `history`, then evaluate all 4 IgG objectives."""
    source_obj = history["objective"]
    m, _ = build_model_with_learned_medium(
        xml_path, source_obj, history["media"],
        history["final_state"], history["final_discrete"])
    results = {"source_medium": source_obj}
    for t in TARGET_OBJS:
        try:
            m.objective = t
            sol = m.optimize()
            results[t] = float(sol[t]) if sol.status == "optimal" else np.nan
        except Exception:
            results[t] = np.nan
    return results


def _pareto_mask(pts: np.ndarray) -> np.ndarray:
    """Return boolean mask of Pareto-dominant rows (maximization)."""
    n = pts.shape[0]
    dominant = np.ones(n, dtype=bool)
    for i in range(n):
        for j in range(n):
            if i == j: continue
            if np.all(pts[j] >= pts[i]) and np.any(pts[j] > pts[i]):
                dominant[i] = False
                break
    return dominant


def _hypervolume_2d(pts: np.ndarray, ref: np.ndarray) -> float:
    """Simple 2D hypervolume (for PC1-PC2-like projections)."""
    pts = pts[np.argsort(-pts[:, 0])]
    hv = 0.0; prev = ref[1]
    for p in pts:
        if p[1] > prev:
            hv += (p[0] - ref[0]) * (p[1] - prev)
            prev = p[1]
    return max(hv, 0.0)


def run_all(xml_path: str, histories: list, out_dir: Path):
    print("  [Pareto] evaluating each medium on all 4 objectives...")
    rows = [_eval_all_objectives(xml_path, h) for h in histories]
    df = pd.DataFrame(rows).set_index("source_medium")
    df.to_csv(out_dir / "pareto_cross_evaluation.csv")

    vals = df[TARGET_OBJS].values
    mask = _pareto_mask(vals)
    df["pareto"] = mask
    df.to_csv(out_dir / "pareto_cross_evaluation.csv")

    # ── Pairwise scatter: 6 subplots for C(4,2) = 6 pairs ────────────────
    pairs = list(combinations(TARGET_OBJS, 2))
    fig, axes = plt.subplots(2, 3, figsize=(15, 9), dpi=130)
    for ax, (a, b) in zip(axes.flatten(), pairs):
        for idx, row in df.iterrows():
            c = COLORS.get(idx, "black"); mk = MARKERS.get(idx, "o")
            ax.scatter(row[a], row[b], color=c, marker=mk, s=140,
                       edgecolor="black", lw=1.2 if row["pareto"] else 0.4,
                       label=idx, alpha=0.9)
            ax.annotate(idx, (row[a], row[b]), xytext=(5, 5),
                        textcoords="offset points", fontsize=7)
        ax.set_xlabel(a); ax.set_ylabel(b)
        ax.axhline(0, color="grey", lw=0.5); ax.axvline(0, color="grey", lw=0.5)
        ax.set_title(f"{a} vs {b}", fontsize=10)
    # single legend
    handles, labels = axes[0, 0].get_legend_handles_labels()
    seen = set(); uniq = [(h, l) for h, l in zip(handles, labels)
                           if not (l in seen or seen.add(l))]
    fig.legend([h for h, l in uniq], [l for h, l in uniq],
               loc="lower center", ncol=4, fontsize=10, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle("Pareto pairwise projections (bold edge = Pareto-dominant)",
                 fontsize=13, y=1.01)
    plt.tight_layout()
    plt.savefig(out_dir / "pareto_pairwise.png", bbox_inches="tight")
    plt.close()

    # ── Summary: hypervolume in each 2D projection ────────────────────────
    ref = vals.min(axis=0) - 0.1 * np.abs(vals.min(axis=0) + 1e-6)
    hv_rows = []
    for i, a in enumerate(TARGET_OBJS):
        for j, b in enumerate(TARGET_OBJS):
            if i >= j: continue
            pts = df[[a, b]].values
            hv = _hypervolume_2d(pts, np.array([ref[i], ref[j]]))
            hv_rows.append({"axis1": a, "axis2": b, "hypervolume_2d": hv})
    pd.DataFrame(hv_rows).to_csv(out_dir / "pareto_hypervolume.csv", index=False)

    print(f"  Pareto-dominant media: {df.index[mask].tolist()}")
    return df
