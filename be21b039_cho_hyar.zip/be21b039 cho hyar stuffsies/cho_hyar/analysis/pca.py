"""PCA of the final media matrix across objectives — ported from v1."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from .helpers import COLORS, MARKERS


def run_all(histories: list, out_dir: Path):
    # Build reaction × objective matrix of final uptake rates
    recs = {}
    for h in histories:
        recs[h["objective"]] = pd.Series(
            {h["media"][i]: h["final_state"][i] for i in range(len(h["media"]))})
    df = pd.DataFrame(recs).fillna(0)          # rows: reactions, cols: objectives
    df.to_csv(out_dir / "HyAR_Final_Media.csv")

    X = df.T.values                             # (n_obj, n_rxn)
    objs = df.columns.tolist()
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    n_comp = min(len(objs), Xs.shape[1])
    pca = PCA(n_components=n_comp)
    scores = pca.fit_transform(Xs)
    ev = np.round(pca.explained_variance_ratio_ * 100, 1)

    # Scree
    fig, ax = plt.subplots(figsize=(7, 5), dpi=130)
    bars = ax.bar([str(i+1) for i in range(n_comp)], ev, color="dodgerblue")
    ax.bar_label(bars, fontsize=10)
    ax.set_xlabel("Principal Component"); ax.set_ylabel("% Explained Variance")
    ax.set_title("PCA Scree – final media matrix")
    ax.grid(True, color="whitesmoke", linewidth=1.25)
    plt.tight_layout()
    plt.savefig(out_dir / "pca_scree.png")
    plt.close()

    # Score plot
    fig, ax = plt.subplots(figsize=(8, 8), dpi=130)
    for i, o in enumerate(objs):
        ax.scatter(scores[i, 0], scores[i, 1],
                   marker=MARKERS[o], color=COLORS[o],
                   s=150, alpha=0.8, label=o)
        ax.annotate(o, (scores[i, 0], scores[i, 1]),
                    xytext=(5, -5), textcoords="offset points", fontsize=9)
    ax.axhline(0, color="black"); ax.axvline(0, color="black")
    ax.set_xlabel(f"PC1 – {ev[0]:.1f}%", size=13)
    ax.set_ylabel(f"PC2 – {ev[1]:.1f}%", size=13)
    ax.set_title("PCA score plot – HyAR final media")
    ax.legend(); plt.tight_layout()
    plt.savefig(out_dir / "pca_scores.png"); plt.close()

    # Biplot
    loadings = pca.components_.T
    reactions = df.index.tolist()
    scale = 5.5
    fig, ax = plt.subplots(figsize=(10, 10), dpi=130)
    for i, o in enumerate(objs):
        ax.scatter(scores[i, 0], scores[i, 1], marker=MARKERS[o],
                   color=COLORS[o], s=150, alpha=0.7, label=o)
        ax.annotate(o, (scores[i, 0], scores[i, 1]),
                    xytext=(5, -5), textcoords="offset points", fontsize=9)
    for j, r in enumerate(reactions):
        ax.arrow(0, 0, loadings[j, 0]*scale, loadings[j, 1]*scale,
                 color="red", alpha=0.45, head_width=0.05)
        ax.text(loadings[j, 0]*scale*1.08, loadings[j, 1]*scale*1.08,
                r, color="blue", ha="center", fontsize=6)
    ax.axhline(0, color="black"); ax.axvline(0, color="black")
    ax.set_xlabel(f"PC1 – {ev[0]:.1f}%", size=13)
    ax.set_ylabel(f"PC2 – {ev[1]:.1f}%", size=13)
    ax.set_title("PCA biplot (scores + loadings)")
    ax.legend(); plt.tight_layout()
    plt.savefig(out_dir / "pca_biplot.png"); plt.close()

    # Loadings bar charts per PC
    for pc in range(min(2, n_comp)):
        order = np.argsort(np.abs(loadings[:, pc]))[::-1]
        fig, ax = plt.subplots(figsize=(14, 4), dpi=130)
        ax.bar(range(len(reactions)), loadings[order, pc], color="steelblue")
        ax.set_xticks(range(len(reactions)))
        ax.set_xticklabels([reactions[i] for i in order], rotation=90, fontsize=7)
        ax.set_title(f"PC{pc+1} loadings – {ev[pc]:.1f}% variance")
        ax.set_ylabel("Loading"); plt.tight_layout()
        plt.savefig(out_dir / f"pca_loadings_PC{pc+1}.png")
        plt.close()

    return df
