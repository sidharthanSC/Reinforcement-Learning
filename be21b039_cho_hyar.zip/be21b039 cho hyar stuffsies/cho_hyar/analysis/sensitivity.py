"""
[Priority 7] Morris elementary-effects sensitivity analysis.

For every active exchange reaction in the learned medium, perturb its
lower bound by ±10% and measure the change in the IgG objective.
Reactions with large |μ*| but small RL-applied delta indicate missed
opportunities; small |μ*| but high toggle activity indicates wasted
action budget.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .helpers import COLORS, obj_safe, build_model_with_learned_medium


def morris_elementary_effects(xml_path: str, history: dict,
                               out_dir: Path,
                               n_trajectories: int = 10,
                               delta_frac: float = 0.1) -> pd.DataFrame:
    obj = history["objective"]
    print(f"  [Morris] {obj}  (n_traj={n_trajectories}, Δ={delta_frac*100:.0f}%)")
    media = history["media"]
    final_disc = history["final_discrete"]
    active = [media[i] for i in range(len(media)) if final_disc[i] == 1]
    if not active:
        return pd.DataFrame()

    rng = np.random.RandomState(0)
    effects = {r: [] for r in active}

    for _ in range(n_trajectories):
        # base model
        m, _ = build_model_with_learned_medium(
            xml_path, obj, media,
            history["final_state"], history["final_discrete"])
        try:
            r0 = float(m.optimize()[obj])
        except Exception:
            continue

        # permute order → one-at-a-time OAT perturbation
        order = rng.permutation(active)
        current_model = m
        prev_obj = r0
        for rxn_id in order:
            rxn = current_model.reactions.get_by_id(rxn_id)
            ref = max(abs(rxn.lower_bound), 1e-3)
            sign = rng.choice([-1, 1])
            rxn.lower_bound = rxn.lower_bound + sign * delta_frac * ref
            try:
                sol = current_model.optimize()
                new_obj = float(sol[obj]) if sol.status == "optimal" else prev_obj
            except Exception:
                new_obj = prev_obj
            # elementary effect
            ee = (new_obj - prev_obj) / (sign * delta_frac * ref + 1e-9)
            effects[rxn_id].append(ee)
            prev_obj = new_obj

    rows = []
    for rxn_id, es in effects.items():
        if not es: continue
        es_arr = np.array(es)
        rows.append({
            "reaction": rxn_id,
            "mu":       float(es_arr.mean()),
            "mu_star":  float(np.abs(es_arr).mean()),   # primary importance metric
            "sigma":    float(es_arr.std()),            # non-linearity / interactions
        })
    df = pd.DataFrame(rows).set_index("reaction")
    df = df.sort_values("mu_star", ascending=False)
    df["objective"] = obj
    df.to_csv(out_dir / f"morris_sensitivity_{obj_safe(obj)}.csv")

    # ── μ* bar + μ-vs-σ scatter ────────────────────────────────────────────
    fig, axes = plt.subplots(1, 2, figsize=(14, max(5, len(df)*0.3)), dpi=130)
    top = df.head(20)
    axes[0].barh(top.index[::-1], top["mu_star"].values[::-1],
                 color=COLORS[obj], alpha=0.85)
    axes[0].set_xlabel("μ* (mean |elementary effect|)")
    axes[0].set_title(f"Top-20 sensitive reactions – {obj}")

    axes[1].scatter(df["mu_star"], df["sigma"], color=COLORS[obj],
                    alpha=0.7, s=50)
    for rxn in df.index[:10]:
        axes[1].annotate(rxn, (df.loc[rxn, "mu_star"], df.loc[rxn, "sigma"]),
                         fontsize=7, xytext=(3, 3), textcoords="offset points")
    axes[1].set_xlabel("μ* (importance)")
    axes[1].set_ylabel("σ (interactions / non-linearity)")
    axes[1].set_title(f"Morris plot – {obj}")
    plt.tight_layout()
    plt.savefig(out_dir / f"morris_{obj_safe(obj)}.png")
    plt.close()
    return df


def run_all(xml_path: str, histories: list, out_dir: Path,
            n_trajectories: int = 10):
    for h in histories:
        morris_elementary_effects(xml_path, h, out_dir, n_trajectories)
