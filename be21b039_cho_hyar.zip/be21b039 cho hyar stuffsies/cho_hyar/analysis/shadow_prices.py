"""
[Priority 5] Shadow prices and reduced costs at the learned state.

Shadow price of a metabolite = marginal objective change per unit relaxation
of its mass balance — directly nominates bottleneck nutrients.

Reduced cost of a reaction    = marginal objective change per unit relaxation
of its bound — flags near-active uptake constraints.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from .helpers import COLORS, obj_safe, build_model_with_learned_medium


def run_for_objective(xml_path: str, history: dict, out_dir: Path,
                      top_n: int = 25) -> tuple:
    obj = history["objective"]
    print(f"  [shadow prices] {obj}")
    m, _ = build_model_with_learned_medium(
        xml_path, obj, history["media"],
        history["final_state"], history["final_discrete"])
    sol = m.optimize()
    if sol.status != "optimal":
        print(f"    FBA failed at converged state ({sol.status})")
        return pd.DataFrame(), pd.DataFrame()

    sp = sol.shadow_prices.sort_values(key=np.abs, ascending=False)
    rc = sol.reduced_costs.sort_values(key=np.abs, ascending=False)

    sp.head(top_n).to_csv(out_dir / f"shadow_prices_{obj_safe(obj)}.csv")
    rc.head(top_n).to_csv(out_dir / f"reduced_costs_{obj_safe(obj)}.csv")

    # plot
    fig, axes = plt.subplots(1, 2, figsize=(14, max(5, top_n*0.25)), dpi=130)
    top_sp = sp.head(top_n)
    axes[0].barh(top_sp.index[::-1], top_sp.values[::-1],
                 color=COLORS[obj], alpha=0.8)
    axes[0].axvline(0, color="black", lw=0.5)
    axes[0].set_title(f"Top-{top_n} shadow prices (metabolites) – {obj}")
    axes[0].set_xlabel("Shadow price")

    top_rc = rc.head(top_n)
    axes[1].barh(top_rc.index[::-1], top_rc.values[::-1],
                 color=COLORS[obj], alpha=0.8)
    axes[1].axvline(0, color="black", lw=0.5)
    axes[1].set_title(f"Top-{top_n} reduced costs (reactions) – {obj}")
    axes[1].set_xlabel("Reduced cost")
    plt.tight_layout()
    plt.savefig(out_dir / f"shadow_prices_{obj_safe(obj)}.png")
    plt.close()
    return sp, rc


def run_all(xml_path: str, histories: list, out_dir: Path):
    for h in histories:
        run_for_objective(xml_path, h, out_dir)
