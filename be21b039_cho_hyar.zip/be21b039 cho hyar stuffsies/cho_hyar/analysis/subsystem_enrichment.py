"""
[Priority 6] Subsystem enrichment of add/remove decisions.

For every subsystem, tests whether the learned add-set is enriched vs
the whole set of reactions in the model (hypergeometric + BH-FDR).
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from scipy.stats import hypergeom

from cobra.io import read_sbml_model
from .helpers import COLORS, obj_safe


def _bh_fdr(pvals: np.ndarray) -> np.ndarray:
    n = len(pvals); order = np.argsort(pvals); ranks = np.empty(n)
    for i, idx in enumerate(order): ranks[idx] = i + 1
    q = pvals * n / ranks
    # monotonize
    sorted_q = np.minimum.accumulate(q[order][::-1])[::-1]
    out = np.empty(n)
    for i, idx in enumerate(order): out[idx] = sorted_q[i]
    return np.clip(out, 0, 1)


def run_for_objective(xml_path: str, history: dict, out_dir: Path) -> pd.DataFrame:
    obj = history["objective"]
    m = read_sbml_model(xml_path)

    media = history["media"]
    final_disc = history["final_discrete"]
    # reactions kept "active" at end
    active_media = {media[i] for i in range(len(media)) if final_disc[i] == 1}

    # subsystem info from the model
    all_rxns = list(m.reactions)
    subsys = {r.id: getattr(r, "subsystem", "") or "UNANNOTATED" for r in all_rxns}

    N = len(all_rxns)           # universe size
    K_sel = len(active_media)   # draws (active media)
    rows = []
    for ss in set(subsys.values()):
        in_ss = {r_id for r_id, s in subsys.items() if s == ss}
        m_ss = len(in_ss)                              # successes in population
        x    = len(active_media & in_ss)               # successes in draws
        if m_ss == 0: continue
        p_enrich = hypergeom.sf(x - 1, N, m_ss, K_sel)
        rows.append({
            "subsystem": ss, "size": m_ss,
            "active_in_subsystem": x,
            "p_enrichment": float(p_enrich),
            "fold_enrichment": (x / K_sel) / (m_ss / N) if K_sel > 0 else 0.0,
        })
    df = pd.DataFrame(rows).sort_values("p_enrichment")
    df["q_fdr"] = _bh_fdr(df["p_enrichment"].values)
    df["objective"] = obj
    df.to_csv(out_dir / f"subsystem_enrichment_{obj_safe(obj)}.csv", index=False)
    return df


def plot_summary(all_dfs: list, out_dir: Path, top_n: int = 15):
    if not all_dfs: return
    all_df = pd.concat(all_dfs)
    # For each objective, show top-N most-enriched subsystems (smallest q)
    sig = all_df.sort_values("q_fdr").head(top_n * len(all_df["objective"].unique()))
    fig, ax = plt.subplots(figsize=(12, max(6, top_n*0.4)), dpi=130)
    piv = (all_df.sort_values("q_fdr")
           .groupby("objective").head(top_n)
           .pivot_table(index="subsystem", columns="objective",
                        values="fold_enrichment", aggfunc="mean"))
    piv = piv.fillna(0)
    piv.plot(kind="barh", ax=ax,
             color=[COLORS.get(c, "grey") for c in piv.columns])
    ax.set_xlabel("Fold enrichment (active/expected)")
    ax.set_title(f"Top {top_n} enriched subsystems per objective")
    ax.legend(title="Objective", bbox_to_anchor=(1.02, 1))
    plt.tight_layout()
    plt.savefig(out_dir / "subsystem_enrichment.png")
    plt.close()


def run_all(xml_path: str, histories: list, out_dir: Path):
    dfs = []
    for h in histories:
        dfs.append(run_for_objective(xml_path, h, out_dir))
    plot_summary(dfs, out_dir)
    return dfs
