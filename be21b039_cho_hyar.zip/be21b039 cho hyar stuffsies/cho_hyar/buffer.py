"""Replay buffer and HyAR-specific mechanisms (LSC, RSC).

All model-touching operations in relabel_latent run on whatever device
the tensors are already on (passed in from the training loop, already moved
to device).  The buffer itself always stores on CPU.
"""
from __future__ import annotations
import random
from collections import deque
import torch
import torch.nn.functional as F
import numpy as np


class ReplayBuffer:
    """Stores transitions on CPU: (s, disc, cont, zx, r, s')."""
    def __init__(self, capacity: int):
        self.buf = deque(maxlen=capacity)

    def add(self, t: tuple):
        self.buf.append(t)

    def sample(self, batch_size: int) -> tuple:
        batch = random.sample(self.buf, batch_size)
        s, disc, cont, zx, r, ns = zip(*batch)
        to_t = lambda x: torch.stack(
            [e if isinstance(e, torch.Tensor)
             else torch.as_tensor(e, dtype=torch.float32)
             for e in x])
        return (to_t(s), to_t(disc), to_t(cont), to_t(zx),
                torch.tensor(r, dtype=torch.float32), to_t(ns))

    def __len__(self):
        return len(self.buf)


# ──────────────────────────────────────────────────────────────────────────────
# Latent Space Constraint (LSC)
# ──────────────────────────────────────────────────────────────────────────────

def compute_lsc_bounds(zx_samples: torch.Tensor, c: float = 96.0):
    """
    c-percentile central range per dimension.
    zx_samples: (N, K, latent_dim) or (N, flat_dim) — CPU tensor from buffer.
    Returns (lo, hi) CPU tensors, shape (flat_dim,).
    """
    flat = zx_samples.reshape(zx_samples.size(0), -1)
    lo = torch.quantile(flat, (1 - c / 100) / 2,       dim=0)
    hi = torch.quantile(flat, 1 - (1 - c / 100) / 2,   dim=0)
    return lo, hi


def apply_lsc(tensor: torch.Tensor,
              lo: torch.Tensor, hi: torch.Tensor) -> torch.Tensor:
    """Re-scale tanh output in [-1,1] to [lo, hi].  Works on any device."""
    device = tensor.device
    lo = lo.to(device); hi = hi.to(device)
    shape = tensor.shape
    flat  = tensor.reshape(shape[0], -1).clamp(-1, 1)
    scaled = lo + (hi - lo) * (flat + 1.0) / 2.0
    return scaled.reshape(shape)


# ──────────────────────────────────────────────────────────────────────────────
# Representation Shift Correction (RSC)
# ──────────────────────────────────────────────────────────────────────────────

def relabel_latent(hyar_repr, state: torch.Tensor, next_state: torch.Tensor,
                   disc_stored: torch.Tensor, cont_stored: torch.Tensor,
                   zx_stored: torch.Tensor, dyn_threshold: float) -> torch.Tensor:
    """
    All input tensors are already on the correct device (moved by the training loop).
    Re-encodes stale latent vectors whose dynamics prediction error exceeds the
    threshold.

    state        : (B, state_dim)   — device
    next_state   : (B, state_dim)   — device
    disc_stored  : (B, K) binary    — device
    cont_stored  : (B, K)           — device
    zx_stored    : (B, K, d2)       — device
    """
    device = state.device
    B, K, d2 = zx_stored.shape

    with torch.no_grad():
        zx_new   = zx_stored.clone()
        delta_true = (next_state - state).unsqueeze(1).expand(B, K, -1)

        # reaction indices: (B*K,) on device
        rxn_idx = (torch.arange(K, device=device)
                   .unsqueeze(0).expand(B, K).reshape(-1))
        k_idx   = disc_stored.long().reshape(-1)          # (B*K,)  on device
        e_k     = hyar_repr.get_embedding(k_idx, rxn_idx).view(B, K, -1)

        zx_flat    = zx_stored.reshape(B * K, d2)
        state_rep  = state.unsqueeze(1).expand(B, K, -1).reshape(B * K, -1)
        e_flat     = e_k.reshape(B * K, -1)

        _, delta_pred = hyar_repr.decode(zx_flat, state_rep, e_flat)

        if delta_pred is not None:
            err = (delta_pred - delta_true.reshape(B * K, -1)
                   ).pow(2).mean(dim=-1)       # (B*K,)
            bad = err > dyn_threshold

            if bad.any():
                xk_flat = cont_stored.reshape(B * K, 1)
                mu, ls  = hyar_repr.encode(xk_flat, state_rep, e_flat)
                z_latest = hyar_repr.reparameterize(mu, ls)
                zx_new_flat = zx_new.reshape(B * K, d2)
                zx_new_flat[bad] = z_latest[bad]
                zx_new = zx_new_flat.reshape(B, K, d2)

    return zx_new


def soft_update(source: torch.nn.Module,
                target: torch.nn.Module, tau: float):
    for p_src, p_tgt in zip(source.parameters(), target.parameters()):
        p_tgt.data.copy_(tau * p_src.data + (1.0 - tau) * p_tgt.data)
