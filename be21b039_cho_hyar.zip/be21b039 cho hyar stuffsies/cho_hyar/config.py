"""
Configuration + CLI argument parser.

All 19 ablation flags from the research audit are exposed here.
Defaults follow the HyAR paper's empirical optima plus the
CHO-specific recommendations from the audit.
"""
import argparse
from pathlib import Path


OBJECTIVES = ["igg_formation", "igg_hc", "igg_lc", "DM_igg[g]"]


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="HyAR for CHO media optimization with ablation flags",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    # ── I/O ───────────────────────────────────────────────────────────────
    p.add_argument("--xml-path", default="/data/users/be21b039/CHO_RL/iCHO2291.xml")
    p.add_argument("--output-dir", default="results")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--objectives", nargs="+", default=OBJECTIVES)

    # ── RL hyperparams ────────────────────────────────────────────────────
    p.add_argument("--num-episodes", type=int, default=40)
    p.add_argument("--max-steps", type=int, default=100)
    p.add_argument("--batch-size", type=int, default=128,
                   help="RL batch size (paper uses 128)")
    p.add_argument("--repr-batch-size", type=int, default=64,
                   help="Representation batch size (paper uses 64)")
    p.add_argument("--buffer-capacity", type=int, default=100_000)
    p.add_argument("--gamma", type=float, default=0.99)
    p.add_argument("--patience", type=int, default=50,
                   help="Steps of constant reward before convergence declared")
    p.add_argument("--warmup-episodes", type=int, default=50,
                   help="Random-policy episodes before RL starts")
    p.add_argument("--warmup-batches", type=int, default=5_000)
    p.add_argument("--repr-train-freq", type=int, default=10,
                   help="Train representation every N episodes")

    # ── HyAR defaults (verified by paper) ──────────────────────────────────
    p.add_argument("--embed-dim", type=int, default=6)
    p.add_argument("--latent-dim", type=int, default=6)
    p.add_argument("--kl-weight", type=float, default=0.5)
    p.add_argument("--dyn-weight-beta", type=float, default=10.0)
    p.add_argument("--lsc-percent", type=float, default=96.0)
    p.add_argument("--tau", type=float, default=5e-3)
    p.add_argument("--action-noise", type=float, default=0.1)
    p.add_argument("--policy-delay", type=int, default=2)
    p.add_argument("--repr-lr", type=float, default=1e-4)
    p.add_argument("--actor-lr", type=float, default=3e-4)
    p.add_argument("--critic-lr", type=float, default=3e-4)

    # ── 19 ABLATION FLAGS from the research audit ──────────────────────────
    # 1. Action encoding (highest-leverage change)
    p.add_argument("--action-encoding", choices=["hyar-k-entry", "factored-bernoulli"],
                   default="factored-bernoulli",
                   help="[Ablation 1] factored-bernoulli is the audit-recommended default")

    # 2. Reward normalization
    p.add_argument("--reward-norm", choices=["none", "fba-max", "welford"],
                   default="fba-max",
                   help="[Ablation 2] fba-max normalizes by single-objective FBA maximum")

    # 3. Continuous parameter reparameterization
    p.add_argument("--action-param", choices=["absolute", "fractional", "log-signed"],
                   default="fractional",
                   help="[Ablation 3] fractional: Δv = α·v_current handles 4-OoM range")

    # 4. Reward shaping
    p.add_argument("--reward-shape", choices=["linear", "chebyshev"],
                   default="linear",
                   help="[Ablation 4] chebyshev covers concave Pareto fronts")

    # 5. Potential-based reward shaping
    p.add_argument("--pbrs", choices=["none", "growth", "pfba"],
                   default="growth",
                   help="[Ablation 5] Potential-based shaping for dense signal")

    # 6. Smoothness penalty (CAPS)
    p.add_argument("--smoothness", choices=["none", "caps"],
                   default="caps",
                   help="[Ablation 6] CAPS smoothness penalty (Mysore+ ICRA 2021)")
    p.add_argument("--smoothness-weight", type=float, default=0.01)

    # 7. Infeasibility handling
    p.add_argument("--infeas-handling", choices=["terminate", "penalty", "relax-fba"],
                   default="penalty",
                   help="[Ablation 7] How to handle infeasible FBA solutions")
    p.add_argument("--infeas-penalty", type=float, default=-10.0)

    # 8. Embedding init
    p.add_argument("--embedding-init", choices=["random", "hand-features"],
                   default="random",
                   help="[Ablation 8] hand-features uses biological priors")

    # 9. Curriculum
    p.add_argument("--curriculum", choices=["none", "rich-to-lean"],
                   default="none",
                   help="[Ablation 9] Progressively restrict medium during training")

    # 10. Switch penalty
    p.add_argument("--switch-penalty", type=float, default=0.001,
                   help="[Ablation 10] λ for |a_t - a_{t-1}| penalty")

    # 11. Policy distribution
    p.add_argument("--policy-dist", choices=["tanh-gaussian", "beta"],
                   default="tanh-gaussian",
                   help="[Ablation 11] Continuous head distribution")

    # 12. Embedding sharing
    p.add_argument("--share-embed", choices=["shared", "per-reaction", "shared+bias"],
                   default="shared+bias",
                   help="[Ablation 12] Parameter-sharing strategy")

    # 13. RL algorithm
    p.add_argument("--algo", choices=["td3", "sac", "ppo"],
                   default="td3",
                   help="[Ablation 13] Underlying RL algorithm")

    # 14-19. HyAR-internal ablations (verified by paper)
    p.add_argument("--rsc", choices=["on", "off"], default="on",
                   help="[Ablation 17] Representation Shift Correction")
    p.add_argument("--encoder-fusion", choices=["elementwise", "concat"],
                   default="elementwise",
                   help="[Ablation 18] VAE encoder conditioning")
    p.add_argument("--dynamics-head", choices=["cascaded", "parallel"],
                   default="cascaded",
                   help="[Ablation 19] Dynamics prediction head structure")
    p.add_argument("--dynamics-prediction", choices=["on", "off"], default="on",
                   help="[Ablation] Use L_Dyn auxiliary loss")

    # ── Analysis switches (top-10 priority from audit) ─────────────────────
    p.add_argument("--run-fva",            action="store_true", default=True)
    p.add_argument("--run-baselines",      action="store_true", default=True)
    p.add_argument("--run-flux-sampling",  action="store_true", default=False,
                   help="Expensive (~5 min/objective); off by default")
    p.add_argument("--n-flux-samples",     type=int, default=5_000)
    p.add_argument("--run-pareto",         action="store_true", default=True)
    p.add_argument("--run-shadow-prices",  action="store_true", default=True)
    p.add_argument("--run-subsystem-enrichment", action="store_true", default=True)
    p.add_argument("--run-sensitivity",    action="store_true", default=True)
    p.add_argument("--run-essentiality",   action="store_true", default=True)
    p.add_argument("--run-discrete-analysis", action="store_true", default=True)
    p.add_argument("--run-hierarchical-clustering", action="store_true", default=True)

    p.add_argument("--skip-training",      action="store_true", default=False,
                   help="Skip RL training, use saved histories for analyses")

    return p


def parse_args():
    return build_parser().parse_args()
