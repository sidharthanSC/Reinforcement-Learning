"""
CHO environment — fixed for iCHO2291 exchange-reaction conventions.

Key design decisions:
  - Biomass upper bound fixed at max_biomass, lower bound = 0
    (model must not exceed max_biomass but doesn't have to hit it exactly;
     setting both lb=ub=max_biomass makes almost every perturbed medium infeasible)
  - Exchange reactions have NEGATIVE lower bounds for uptake (lb<0, ub=0)
    _apply_delta shifts lb MORE negative (more uptake) when cont < 0,
    and LESS negative (less uptake) when cont > 0
  - _set_bounds is used everywhere to avoid cobra lb>ub validation crashes
"""
from __future__ import annotations
import numpy as np
import cobra
from cobra.io import read_sbml_model
from copy import deepcopy


# Hard clamp for exchange reaction bounds — iCHO2291 exchanges are in mmol/gDW/h
_BOUND_MIN = -1000.0
_BOUND_MAX  =  1000.0


def _set_bounds(rxn: cobra.Reaction, new_lb: float, new_ub: float):
    """
    Set both bounds atomically without ever violating lb <= ub mid-assignment.
    Recipe: widen ub first, then set lb, then final ub.
    Guards against nan/inf which cause the GLPK 'nan bounds' exception.
    """
    # Reject nan/inf — reset to (0, 0) as a safe fallback
    if not (np.isfinite(new_lb) and np.isfinite(new_ub)):
        new_lb, new_ub = 0.0, 0.0
    safe_lo = float(np.clip(min(new_lb, new_ub), _BOUND_MIN, _BOUND_MAX))
    safe_hi = float(np.clip(max(new_lb, new_ub), _BOUND_MIN, _BOUND_MAX))
    rxn.upper_bound = max(rxn.upper_bound if np.isfinite(rxn.upper_bound) else 0.0,
                          safe_hi)
    rxn.lower_bound = safe_lo
    rxn.upper_bound = safe_hi


class CHOEnvironment:

    def __init__(self, model: cobra.Model, objective: str,
                 media: list, max_biomass: float, args):
        self.model = model
        self.objective = objective
        self.media = media
        self.K = len(media)
        self.args = args

        self.model.objective = objective

        # Biomass: require at least 10% of max growth (prevents trivial zero
        # solution where the model ignores all nutrients and IgG = 0),
        # but don't force exactly max (that makes every perturbation infeasible).
        self.model.reactions.get_by_id("biomass_cho").lower_bound = 0.1 * max_biomass
        self.model.reactions.get_by_id("biomass_cho").upper_bound = max_biomass
        self._max_biomass = max_biomass

        # cache initial (default) bounds — used as the feasible starting point
        self._init_bounds = {
            r: (self.model.reactions.get_by_id(r).lower_bound,
                self.model.reactions.get_by_id(r).upper_bound)
            for r in media
        }

        # reward normalization
        self.fba_max = self._compute_fba_max() if args.reward_norm == "fba-max" else 1.0
        self._welford = _WelfordStats() if args.reward_norm == "welford" else None

        # Scale infeasibility penalty to fba_max so it's always ~2× the best
        # feasible reward after normalization — prevents the 200× gap that
        # causes gradient explosions when the policy explores reaction removal.
        # Raw penalty = -2 * fba_max → normalised R_infeas = -2.0
        self._infeas_penalty = -2.0 * self.fba_max

        self._last_potential = None
        self._prev_disc = None
        self._prev_cont = None
        self._curriculum_progress = 0.0
        self.active = np.ones(self.K, dtype=bool)

    # ── helpers ───────────────────────────────────────────────────────────

    def _compute_fba_max(self) -> float:
        """Upper bound: unrestricted medium, uncapped biomass."""
        tmp = self.model.copy()
        for r in self.media:
            tmp.reactions.get_by_id(r).lower_bound = -1000
            tmp.reactions.get_by_id(r).upper_bound =  1000
        tmp.reactions.get_by_id("biomass_cho").lower_bound = 0.1 * self._max_biomass
        tmp.reactions.get_by_id("biomass_cho").upper_bound = self._max_biomass
        tmp.objective = self.objective
        sol = tmp.optimize()
        return max(abs(float(sol[self.objective])), 1e-6)

    def get_state(self) -> np.ndarray:
        return np.array(
            [self.model.reactions.get_by_id(r).lower_bound for r in self.media],
            dtype=np.float32
        )

    def get_key_fluxes(self) -> dict:
        sol = self.model.optimize()
        keys = ["biomass_cho", "igg_formation", "igg_hc", "igg_lc", "DM_igg[g]"]
        return {k: float(sol[k]) if sol.status == "optimal" else 0.0
                for k in keys}

    def reset_to_default_medium(self):
        """Restore all media reactions to their published default bounds."""
        for r in self.media:
            init_lb, init_ub = self._init_bounds[r]
            rxn = self.model.reactions.get_by_id(r)
            _set_bounds(rxn, init_lb, init_ub)
        self.active = np.ones(self.K, dtype=bool)

    # ── action parameter transform ────────────────────────────────────────

    def _apply_delta(self, rxn_id: str, raw_delta: float):
        """
        Apply delta to an exchange reaction's lower bound only.

        Exchange reactions in iCHO2291: lb < 0 (uptake), ub = 0.
        We only move the lower bound (uptake rate); upper bound stays at 0.
        This avoids the lb > ub problem entirely for standard exchanges.
        """
        rxn = self.model.reactions.get_by_id(rxn_id)
        mode = self.args.action_param

        if mode == "absolute":
            delta = raw_delta
        elif mode == "fractional":
            ref = max(abs(rxn.lower_bound), 0.1)
            delta = raw_delta * ref
        elif mode == "log-signed":
            sign = np.sign(raw_delta) if raw_delta != 0 else 0
            mag  = 10 ** (abs(raw_delta) * 3 - 2)
            delta = sign * mag
        else:
            delta = raw_delta

        # Guard: if delta or current bound is nan, reset reaction to init bounds
        if not np.isfinite(delta) or not np.isfinite(rxn.lower_bound):
            init_lb, init_ub = self._init_bounds[rxn_id]
            _set_bounds(rxn, init_lb, init_ub)
            return
        # Clamp delta to a safe range to prevent runaway bound drift
        delta = float(np.clip(delta, -100.0, 100.0))
        # Only shift the lower bound (uptake limit) — keep ub unchanged
        # Clamp so lb never goes above 0 (can't force export via medium)
        new_lb = min(rxn.lower_bound + delta, 0.0)
        new_ub = rxn.upper_bound if np.isfinite(rxn.upper_bound) else 0.0
        _set_bounds(rxn, new_lb, new_ub)

    # ── curriculum ────────────────────────────────────────────────────────

    def set_curriculum_progress(self, p: float):
        self._curriculum_progress = float(np.clip(p, 0, 1))

    # ── core step ─────────────────────────────────────────────────────────

    def step(self, discrete_action: np.ndarray, continuous_param: np.ndarray):
        for i, rxn_id in enumerate(self.media):
            rxn = self.model.reactions.get_by_id(rxn_id)
            if discrete_action[i] == 1:
                self._apply_delta(rxn_id, float(continuous_param[i]))
            else:
                # Deactivate: block uptake by setting lb=0 (ub already 0)
                _set_bounds(rxn, 0.0, rxn.upper_bound)
            self.active[i] = bool(discrete_action[i])

        # curriculum
        if self.args.curriculum == "rich-to-lean" and self._curriculum_progress > 0:
            for i, rxn_id in enumerate(self.media):
                if discrete_action[i] == 0:
                    continue
                init_lb, init_ub = self._init_bounds[rxn_id]
                rxn = self.model.reactions.get_by_id(rxn_id)
                p = self._curriculum_progress
                new_lb = (1 - p) * rxn.lower_bound + p * init_lb
                new_ub = rxn.upper_bound
                _set_bounds(rxn, new_lb, new_ub)

        # FBA
        sol = self.model.optimize()
        info = {"status": sol.status}

        if sol.status != "optimal":
            if self.args.infeas_handling == "terminate":
                info["terminate"] = True
                raw = self._infeas_penalty
            elif self.args.infeas_handling == "relax-fba":
                raw = self._relax_fba() or self._infeas_penalty
            else:
                raw = self._infeas_penalty
        else:
            raw = float(sol[self.objective])

        # reward normalization
        norm_reward = raw
        if self.args.reward_norm == "fba-max":
            norm_reward = raw / self.fba_max
        elif self.args.reward_norm == "welford":
            self._welford.update(raw)
            norm_reward = self._welford.normalize(raw)

        # PBRS
        pbrs_bonus = 0.0
        if self.args.pbrs != "none" and sol.status == "optimal":
            phi = self._potential(sol)
            if self._last_potential is not None:
                pbrs_bonus = self.args.gamma * phi - self._last_potential
            self._last_potential = phi

        # switch / smoothness penalty
        penalty = 0.0
        if self._prev_disc is not None and self.args.switch_penalty > 0:
            penalty += self.args.switch_penalty * float(
                np.abs(discrete_action - self._prev_disc).sum())
        if self._prev_cont is not None and self.args.smoothness == "caps":
            penalty += self.args.smoothness_weight * float(
                np.linalg.norm(continuous_param - self._prev_cont))

        self._prev_disc = discrete_action.copy()
        self._prev_cont = continuous_param.copy()

        reward = norm_reward + pbrs_bonus - penalty
        info.update({"raw_reward": raw, "norm_reward": norm_reward,
                     "pbrs_bonus": pbrs_bonus, "penalty": penalty})
        return self.get_state(), float(reward), info

    def _potential(self, sol) -> float:
        if self.args.pbrs == "growth":
            return float(sol["biomass_cho"])
        if self.args.pbrs == "pfba":
            return -float(np.sum(np.abs(sol.fluxes.values))) / 1e4
        return 0.0

    def _relax_fba(self):
        try:
            with self.model as m:
                for r in self.media:
                    rxn = m.reactions.get_by_id(r)
                    rxn.lower_bound = min(rxn.lower_bound * 10, -1000)
                    rxn.upper_bound = max(rxn.upper_bound * 10,  1000)
                sol = m.optimize()
                return float(sol[self.objective]) if sol.status == "optimal" else None
        except Exception:
            return None


class _WelfordStats:
    def __init__(self):
        self.n = 0; self.mean = 0.0; self.M2 = 0.0

    def update(self, x: float):
        self.n += 1
        d = x - self.mean
        self.mean += d / self.n
        self.M2   += d * (x - self.mean)

    def normalize(self, x: float) -> float:
        if self.n < 2: return x
        return (x - self.mean) / max(self.M2 / (self.n - 1), 1e-6) ** 0.5


def build_env(args, objective: str):
    base  = read_sbml_model(args.xml_path)
    media = [r for r, b in base.medium.items() if b != 1000]
    max_biomass = float(base.optimize()["biomass_cho"])
    model = deepcopy(base)
    return CHOEnvironment(model, objective, media, max_biomass, args), media, max_biomass
