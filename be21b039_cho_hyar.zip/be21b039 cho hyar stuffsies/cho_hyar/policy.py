"""
Latent policy networks:

Two actor variants:
  FactoredBernoulliActor — K independent sigmoid heads for on/off
                           + K continuous heads for Δ per reaction
                           (audit-recommended for K ≈ 30-50)

  HyARKEntryActor        — original HyAR actor, outputs (e, zx) vectors
                           of size (K*d1 + K*d2).  Kept for ablation.

Double critic shared by both.
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F


def _mlp(in_dim, out_dim):
    return nn.Sequential(
        nn.Linear(in_dim, 256), nn.LayerNorm(256), nn.ReLU(),
        nn.Linear(256, 256), nn.ReLU(),
        nn.Linear(256, out_dim),
    )


class FactoredBernoulliActor(nn.Module):
    """
    For each reaction k:
        p_k ∈ [0, 1]        — probability of 'on'
        z_k ∈ R^{latent_dim} — latent continuous parameter
    """
    def __init__(self, state_dim: int, K: int, latent_dim: int):
        super().__init__()
        self.K = K; self.latent_dim = latent_dim
        self.trunk = nn.Sequential(
            nn.Linear(state_dim, 256), nn.LayerNorm(256), nn.ReLU(),
            nn.Linear(256, 256), nn.ReLU(),
        )
        self.head_logits = nn.Linear(256, K)         # Bernoulli logits
        self.head_latent = nn.Linear(256, K * latent_dim)
        # Initialise logit bias to +2.0 → sigmoid(2.0) ≈ 0.88
        # Agent starts mostly-active; learning drives it toward the optimum
        nn.init.constant_(self.head_logits.bias, 2.0)

    def forward(self, state):
        h = self.trunk(state)
        logits = self.head_logits(h)                 # (B, K)
        probs = torch.sigmoid(logits)
        zx = torch.tanh(self.head_latent(h)).view(-1, self.K, self.latent_dim)
        return probs, zx

    def sample(self, state, noise: float = 0.0):
        probs, zx = self.forward(state)
        # Bernoulli sampling for discrete part
        disc = torch.bernoulli(probs)
        if noise > 0:
            zx = zx + torch.randn_like(zx) * noise
        return disc, zx, probs


class HyARKEntryActor(nn.Module):
    """
    Original HyAR-style actor.  Output dim = K*(d1+d2), reshaped to (K, d1+d2).
    Used when --action-encoding hyar-k-entry.
    """
    def __init__(self, state_dim: int, K: int, embed_dim: int, latent_dim: int):
        super().__init__()
        self.K = K; self.embed_dim = embed_dim; self.latent_dim = latent_dim
        out_dim = K * (embed_dim + latent_dim)
        self.net = nn.Sequential(
            nn.Linear(state_dim, 256), nn.LayerNorm(256), nn.ReLU(),
            nn.Linear(256, 256), nn.ReLU(),
            nn.Linear(256, out_dim), nn.Tanh(),
        )

    def forward(self, state):
        out = self.net(state)
        e = out[..., :self.K*self.embed_dim].view(-1, self.K, self.embed_dim)
        zx = out[..., self.K*self.embed_dim:].view(-1, self.K, self.latent_dim)
        return e, zx


class Critic(nn.Module):
    """Double critic — shared for both actor types."""
    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()
        in_dim = state_dim + action_dim
        self.q1 = _mlp(in_dim, 1)
        self.q2 = _mlp(in_dim, 1)

    def forward(self, state, action_flat):
        x = torch.cat([state, action_flat], dim=-1)
        return self.q1(x), self.q2(x)

    def q1_only(self, state, action_flat):
        return self.q1(torch.cat([state, action_flat], dim=-1))
