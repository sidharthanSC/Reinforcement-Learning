"""
HyAR representation model:
    - Learnable embedding (K entries, or 2 entries if factored-bernoulli)
    - Conditional VAE with:
        * element-wise product OR concat conditioning
        * cascaded OR parallel dynamics head
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F


# ──────────────────────────────────────────────────────────────────────────────
# Embedding table
# ──────────────────────────────────────────────────────────────────────────────

class DiscreteEmbeddingTable(nn.Module):
    """
    Two modes:
        mode="k-entry"   — K embeddings, one per reaction (original HyAR).
        mode="bernoulli" — 2 embeddings {off, on}, shared across all reactions.
                           A per-reaction bias is added (share-embed="shared+bias").
    """

    def __init__(self, K: int, embed_dim: int, mode: str = "k-entry",
                 share_embed: str = "shared+bias",
                 reaction_features: torch.Tensor = None):
        super().__init__()
        self.K = K
        self.embed_dim = embed_dim
        self.mode = mode
        self.share_embed = share_embed

        if mode == "k-entry":
            self.table = nn.Embedding(K, embed_dim)
            nn.init.uniform_(self.table.weight, -1.0, 1.0)
        elif mode == "bernoulli":
            # Only 2 embeddings: off/on
            self.table = nn.Embedding(2, embed_dim)
            nn.init.uniform_(self.table.weight, -1.0, 1.0)

            if share_embed == "per-reaction":
                # per-reaction additional embedding
                self.reaction_bias = nn.Embedding(K, embed_dim)
                nn.init.uniform_(self.reaction_bias.weight, -0.1, 0.1)
            elif share_embed == "shared+bias":
                # small additive bias per reaction
                self.reaction_bias = nn.Parameter(torch.zeros(K, embed_dim))
                nn.init.uniform_(self.reaction_bias, -0.1, 0.1)
            else:  # "shared"
                self.reaction_bias = None

            # Optional hand-crafted biological features
            if reaction_features is not None:
                self.register_buffer("reaction_features", reaction_features)
                # project features to embed_dim
                self.feat_proj = nn.Linear(reaction_features.size(1), embed_dim)
            else:
                self.reaction_features = None
                self.feat_proj = None
        else:
            raise ValueError(mode)

    def forward(self, k_indices: torch.Tensor,
                rxn_indices: torch.Tensor = None) -> torch.Tensor:
        """
        k_indices: for k-entry mode — reaction index; for bernoulli — {0,1}
        rxn_indices: required only in bernoulli mode (reaction idx per sample)
        Returns (B, embed_dim).
        """
        e = self.table(k_indices)

        if self.mode == "bernoulli" and rxn_indices is not None:
            if isinstance(self.reaction_bias, nn.Embedding):
                e = e + self.reaction_bias(rxn_indices)
            elif self.reaction_bias is not None:
                e = e + self.reaction_bias[rxn_indices]
            if self.feat_proj is not None:
                e = e + self.feat_proj(self.reaction_features[rxn_indices])
        return e

    def lookup_all(self) -> torch.Tensor:
        idx = torch.arange(self.table.num_embeddings, device=self.table.weight.device)
        return self.table(idx)

    def nearest_k(self, e_vec: torch.Tensor) -> torch.Tensor:
        all_e = self.lookup_all()
        dists = torch.cdist(e_vec, all_e)
        return dists.argmin(dim=1)


# ──────────────────────────────────────────────────────────────────────────────
# Conditional VAE
# ──────────────────────────────────────────────────────────────────────────────

class ConditionalVAEEncoder(nn.Module):
    def __init__(self, x_dim: int, state_dim: int, embed_dim: int,
                 latent_dim: int, fusion: str = "elementwise"):
        super().__init__()
        self.fusion = fusion
        self.fc_x = nn.Linear(x_dim, 256)
        self.fc_cond = nn.Linear(state_dim + embed_dim, 256)
        in_dim = 256 if fusion == "elementwise" else 512
        self.fc_mid = nn.Linear(in_dim, 256)
        self.fc_mu = nn.Linear(256, latent_dim)
        self.fc_logstd = nn.Linear(256, latent_dim)

    def forward(self, xk, state, e_k):
        h_x = F.relu(self.fc_x(xk))
        h_c = F.relu(self.fc_cond(torch.cat([state, e_k], dim=-1)))
        if self.fusion == "elementwise":
            h = F.relu(self.fc_mid(h_x * h_c))
        else:
            h = F.relu(self.fc_mid(torch.cat([h_x, h_c], dim=-1)))
        return self.fc_mu(h), self.fc_logstd(h)


class ConditionalVAEDecoder(nn.Module):
    def __init__(self, latent_dim: int, state_dim: int, embed_dim: int,
                 x_dim: int, fusion: str = "elementwise",
                 head_type: str = "cascaded",
                 dyn_pred: bool = True):
        super().__init__()
        self.fusion = fusion
        self.head_type = head_type
        self.dyn_pred = dyn_pred

        self.fc_z = nn.Linear(latent_dim, 256)
        self.fc_cond = nn.Linear(state_dim + embed_dim, 256)
        in_dim = 256 if fusion == "elementwise" else 512
        self.fc_trunk = nn.Linear(in_dim, 256)

        self.fc_recon = nn.Linear(256, x_dim)

        if dyn_pred:
            if head_type == "cascaded":
                self.fc_pred1 = nn.Linear(256, 256)
                self.fc_pred2 = nn.Linear(256, state_dim)
            else:  # parallel
                self.fc_pred1 = nn.Linear(in_dim, 256)
                self.fc_pred2 = nn.Linear(256, state_dim)

    def forward(self, zx, state, e_k):
        h_z = F.relu(self.fc_z(zx))
        h_c = F.relu(self.fc_cond(torch.cat([state, e_k], dim=-1)))
        if self.fusion == "elementwise":
            fused = h_z * h_c
        else:
            fused = torch.cat([h_z, h_c], dim=-1)
        h = F.relu(self.fc_trunk(fused))
        x_recon = self.fc_recon(h)

        delta_pred = None
        if self.dyn_pred:
            if self.head_type == "cascaded":
                delta_pred = self.fc_pred2(F.relu(self.fc_pred1(h)))
            else:
                delta_pred = self.fc_pred2(F.relu(self.fc_pred1(fused)))
        return x_recon, delta_pred


class HyARRepresentation(nn.Module):
    def __init__(self, K: int, state_dim: int, args,
                 reaction_features: torch.Tensor = None):
        super().__init__()
        self.K = K
        self.state_dim = state_dim
        self.embed_dim = args.embed_dim
        self.latent_dim = args.latent_dim
        self.args = args

        mode = ("bernoulli" if args.action_encoding == "factored-bernoulli"
                else "k-entry")
        self.emb = DiscreteEmbeddingTable(
            K, args.embed_dim,
            mode=mode,
            share_embed=args.share_embed,
            reaction_features=reaction_features
        )
        self.encoder = ConditionalVAEEncoder(
            x_dim=1, state_dim=state_dim, embed_dim=args.embed_dim,
            latent_dim=args.latent_dim, fusion=args.encoder_fusion
        )
        self.decoder = ConditionalVAEDecoder(
            latent_dim=args.latent_dim, state_dim=state_dim,
            embed_dim=args.embed_dim, x_dim=1,
            fusion=args.encoder_fusion,
            head_type=args.dynamics_head,
            dyn_pred=(args.dynamics_prediction == "on")
        )
        self.mode = mode

    def get_embedding(self, k_idx: torch.Tensor, rxn_idx: torch.Tensor = None):
        if self.mode == "bernoulli":
            return self.emb(k_idx, rxn_idx)
        return self.emb(k_idx)

    def encode(self, xk, state, e_k):
        return self.encoder(xk, state, e_k)

    def decode(self, zx, state, e_k):
        return self.decoder(zx, state, e_k)

    def reparameterize(self, mu, log_std):
        std = torch.clamp(log_std.exp(), 1e-4, 10.0)
        eps = torch.randn_like(std)
        return mu + eps * std

    def loss(self, xk, state, k_idx, next_state,
             rxn_idx: torch.Tensor = None) -> torch.Tensor:
        e_k = self.get_embedding(k_idx, rxn_idx)
        mu, log_std = self.encode(xk, state, e_k)
        zx = self.reparameterize(mu, log_std)
        x_recon, delta_pred = self.decode(zx, state, e_k)

        recon = F.mse_loss(x_recon, xk)
        kl = -0.5 * (1 + 2*log_std - mu.pow(2) - log_std.exp().pow(2)).mean()
        loss = recon + self.args.kl_weight * kl

        if delta_pred is not None:
            dyn = F.mse_loss(delta_pred, next_state - state)
            loss = loss + self.args.dyn_weight_beta * dyn
        return loss
