"""
Top-level entry point.

Usage
-----
    python -m cho_hyar.run                            # full defaults
    python -m cho_hyar.run --action-encoding hyar-k-entry  # ablation
    python -m cho_hyar.run --skip-training            # analyses only (from saved histories)

Output
------
    <output-dir>/
        history_<obj>.json                # raw per-objective training log
        reward_curves_<obj>.png           # basic plots  [§1]
        state_trajectory_<obj>.png
        discrete_heatmap_<obj>.png
        key_fluxes_<obj>.png
        discrete_stats_<obj>.csv          # discrete analysis
        toggle_counts_<obj>.png
        activity_bar_<obj>.png
        add_remove_timeline_<obj>.png
        reward_vs_active_<obj>.png
        xobj_activity_heatmap.png         # cross-objective discrete
        xobj_final_state_heatmap.png
        fva_<obj>.csv / fva_*.png         # Priority 1  FVA
        baselines.csv / baselines_bar.png # Priority 2  Baselines
        flux_samples_<obj>.csv            # Priority 3  Flux sampling (optional)
        flux_sampling_violins.png
        pareto_cross_evaluation.csv       # Priority 4  Pareto
        pareto_pairwise.png
        pareto_hypervolume.csv
        shadow_prices_<obj>.*             # Priority 5
        reduced_costs_<obj>.csv
        subsystem_enrichment_<obj>.csv    # Priority 6
        subsystem_enrichment.png
        morris_sensitivity_<obj>.csv      # Priority 7
        morris_<obj>.png
        essentiality_<obj>.csv            # Priority 8
        essentiality_matrix.png / .csv / _summary.txt
        convergence_<obj>.png             # Priority 9
        convergence_summary.csv
        hierarchical_clustermap.png       # Priority 10
        jaccard_*.png / .csv
        pca_*.png / HyAR_Final_Media.csv  # original PCA suite
"""
from __future__ import annotations
import json, traceback
from pathlib import Path

from .config import parse_args
from .trainer import train_objective
from .analysis import (
    helpers, basic_plots, discrete, fva, baselines, flux_sampling, pareto,
    shadow_prices, subsystem_enrichment, sensitivity, essentiality,
    convergence, clustering, pca
)


def main():
    args = parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # persist config used
    with open(out / "config.json", "w") as f:
        json.dump(vars(args), f, indent=2, default=str)

    # ── 1. Training (or load from disk) ────────────────────────────────────
    histories = []
    for obj in args.objectives:
        hist_path = out / f"history_{helpers.obj_safe(obj)}.json"
        if args.skip_training and hist_path.exists():
            print(f"  [skip-training] Loading history for {obj}")
            histories.append(helpers.load_history(out, obj))
            continue
        try:
            h = train_objective(args, obj, out)
            histories.append(h)
        except Exception as e:
            print(f"  ERROR training {obj}: {e}")
            traceback.print_exc()

    if not histories:
        print("No histories available — aborting analyses")
        return

    # ── 2. Basic + discrete per-objective plots ────────────────────────────
    print("\n" + "="*66)
    print("  Analysis phase")
    print("="*66)
    for h in histories:
        basic_plots.plot_reward_curves(h, out, args.patience)
        basic_plots.plot_state_trajectory(h, out, args.patience)
        basic_plots.plot_discrete_heatmap(h, out)
        basic_plots.plot_key_fluxes(h, out)
        if args.run_discrete_analysis:
            discrete.per_objective(h, out)

    if args.run_discrete_analysis:
        discrete.cross_objective(histories, out)

    # ── 3. Priority 1-10 FBA analyses ─────────────────────────────────────
    def _safe(name, fn, *a, **kw):
        try:
            print(f"\n→ {name}")
            return fn(*a, **kw)
        except Exception as e:
            print(f"  {name} FAILED: {e}")
            traceback.print_exc()
            return None

    if args.run_fva:
        _safe("FVA (Priority 1)",
              fva.run_all, args.xml_path, histories, out)

    if args.run_baselines:
        _safe("Baselines (Priority 2)",
              baselines.run_all, args.xml_path, histories, out)

    if args.run_flux_sampling:
        _safe("Flux sampling (Priority 3)",
              flux_sampling.run_all,
              args.xml_path, histories, out, args.n_flux_samples)

    if args.run_pareto:
        _safe("Pareto (Priority 4)",
              pareto.run_all, args.xml_path, histories, out)

    if args.run_shadow_prices:
        _safe("Shadow prices (Priority 5)",
              shadow_prices.run_all, args.xml_path, histories, out)

    if args.run_subsystem_enrichment:
        _safe("Subsystem enrichment (Priority 6)",
              subsystem_enrichment.run_all, args.xml_path, histories, out)

    if args.run_sensitivity:
        _safe("Morris sensitivity (Priority 7)",
              sensitivity.run_all, args.xml_path, histories, out)

    if args.run_essentiality:
        _safe("Essentiality (Priority 8)",
              essentiality.run_all, args.xml_path, histories, out)

    _safe("Convergence diagnostics (Priority 9)",
          convergence.run_all, histories, out)

    if args.run_hierarchical_clustering:
        _safe("Hierarchical clustering + Jaccard (Priority 10)",
              clustering.run_all, histories, out)

    _safe("PCA of final media",
          pca.run_all, histories, out)

    # ── 4. Print summary ───────────────────────────────────────────────────
    print("\n" + "="*66)
    print(f"  ✓ All done.  Output directory: {out.resolve()}")
    print("="*66)
    files = sorted(out.iterdir())
    print(f"  {len(files)} files generated:")
    groups = {}
    for f in files:
        ext = f.suffix
        groups.setdefault(ext, []).append(f.name)
    for ext, fs in sorted(groups.items()):
        print(f"    {ext}: {len(fs)} files")


if __name__ == "__main__":
    main()
