"""
HyAR-TD3 training loop.

Device-safe: every tensor that touches the model is explicitly moved to
`device` before use.  The replay buffer always stores on CPU (cheap memory)
and tensors are moved to device at sample time.
"""
from __future__ import annotations
import json, random
from copy import deepcopy
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from .environment import build_env
from .representation import HyARRepresentation
from .policy import FactoredBernoulliActor, Critic
from .buffer import (ReplayBuffer, compute_lsc_bounds, apply_lsc,
                     relabel_latent, soft_update)


def _seed_everything(seed: int):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)


def _t(x, device, dtype=torch.float32) -> torch.Tensor:
    """Convenience: numpy/list → tensor on device."""
    if isinstance(x, torch.Tensor):
        return x.to(device=device, dtype=dtype)
    return torch.tensor(x, dtype=dtype, device=device)


def _decode_continuous(hyar_repr, zx: torch.Tensor, state: torch.Tensor,
                       disc: torch.Tensor) -> torch.Tensor:
    """
    zx   : (B, K, latent_dim) — on device
    state: (B, state_dim)     — on device
    disc : (B, K) binary      — on device
    Returns Δ vector (B, K) clamped to [-1, 0.05], on device.
    """
    B, K, d2 = zx.shape
    device = state.device
    rxn_idx = torch.arange(K, device=device).unsqueeze(0).expand(B, K)
    k_idx   = disc.long()                          # already on device
    e_k     = hyar_repr.get_embedding(
                  k_idx.flatten(), rxn_idx.flatten()
              ).view(B, K, -1)                     # device ✓ (model on device)

    state_rep = state.unsqueeze(1).expand(B, K, -1).reshape(B * K, -1)
    zx_flat   = zx.reshape(B * K, d2)
    e_flat    = e_k.reshape(B * K, -1)
    x_recon, _ = hyar_repr.decode(zx_flat, state_rep, e_flat)
    return x_recon.view(B, K).clamp(-0.5, 0.05)


# ──────────────────────────────────────────────────────────────────────────────
# Warm-up
# ──────────────────────────────────────────────────────────────────────────────

def _warmup(env, hyar_repr, buffer, args, K, device):
    """
    Exploration to fill the replay buffer starting from the DEFAULT medium.

    FIX: do NOT randomly zero reactions. iCHO2291 exchange reactions have
    negative lb for uptake; zeroing >50% randomly makes the LP infeasible
    almost every step and the policy never sees a positive reward.

    Strategy:
      - Keep ALL reactions active (disc=1) throughout warmup
      - Apply small random deltas around the published default bounds
      - This ensures the model stays near feasible region
    """
    n_steps = max(args.warmup_episodes * args.max_steps, args.batch_size * 3)
    # Always start from the clean default medium
    env.reset_to_default_medium()
    s = env.get_state()

    for step_i in range(n_steps):
        # All reactions active during warmup — explore around feasible region
        disc = np.ones(K, dtype=np.float32)
        # Small deltas: mostly tightening/loosening uptake rates slightly
        # Range: [-0.2, 0.05] keeps us close to default bounds
        cont = np.random.uniform(-0.2, 0.05, size=(K,)).astype(np.float32)
        # Every 10 steps, reset to default to avoid drifting too far
        if step_i % 10 == 0:
            env.reset_to_default_medium()
            s = env.get_state()

        with torch.no_grad():
            # ── all on device ──────────────────────────────────────────────
            s_dev     = _t(s,    device)                          # (K_state,)
            disc_dev  = _t(disc, device)                          # (K,)
            rxn_idx   = torch.arange(K, device=device)           # (K,)

            e_k = hyar_repr.get_embedding(
                      disc_dev.long(), rxn_idx                    # both on device
                  )                                               # (K, d1)

            xk_dev = _t(cont, device).unsqueeze(-1)              # (K, 1)
            s_exp  = s_dev.unsqueeze(0).expand(K, -1)            # (K, state_dim)

            mu, ls = hyar_repr.encode(xk_dev, s_exp, e_k)
            zx = hyar_repr.reparameterize(mu, ls)                # (K, latent_dim)

        ns, r, _ = env.step(disc.astype(int), cont)

        # store on CPU to save GPU memory
        buffer.add((
            _t(s,  "cpu"),
            _t(disc, "cpu"),
            _t(cont, "cpu"),
            zx.cpu(),                                            # (K, latent_dim)
            float(r),
            _t(ns, "cpu"),
        ))
        s = ns


# ──────────────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────────────

def train_objective(args, objective: str, out_dir: Path) -> dict:
    _seed_everything(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"\n{'='*66}")
    print(f"  Training HyAR  |  Objective: {objective}  |  device: {device}")
    print(f"{'='*66}")

    env, media, max_biomass = build_env(args, objective)
    K         = env.K
    state_dim = K

    # ── models — all on device ─────────────────────────────────────────────
    hyar_repr    = HyARRepresentation(K, state_dim, args).to(device)
    actor        = FactoredBernoulliActor(state_dim, K, args.latent_dim).to(device)
    actor_target = deepcopy(actor).to(device)
    action_dim   = K + K * args.latent_dim
    critic        = Critic(state_dim, action_dim).to(device)
    critic_target = deepcopy(critic).to(device)

    opt_repr   = torch.optim.Adam(hyar_repr.parameters(), lr=args.repr_lr)
    opt_actor  = torch.optim.Adam(actor.parameters(),     lr=args.actor_lr)
    opt_critic = torch.optim.Adam(critic.parameters(),    lr=args.critic_lr)

    buffer = ReplayBuffer(args.buffer_capacity)

    # ── warm-up ───────────────────────────────────────────────────────────
    print("  Warm-up: random exploration...")
    _warmup(env, hyar_repr, buffer, args, K, device)

    # ── VAE pre-training ──────────────────────────────────────────────────
    print("  Pre-training HyAR representation...")
    n_pre = min(args.warmup_batches, len(buffer) * 4)
    for _ in range(n_pre):
        if len(buffer) < args.repr_batch_size:
            break
        s_b, disc_b, cont_b, _, _, ns_b = buffer.sample(args.repr_batch_size)
        B = s_b.size(0)
        # flatten to per-reaction format, move to device
        s_rep  = s_b.unsqueeze(1).expand(B, K, -1).reshape(B*K, -1).to(device)
        ns_rep = ns_b.unsqueeze(1).expand(B, K, -1).reshape(B*K, -1).to(device)
        rxn_idx = torch.arange(K, device=device).unsqueeze(0).expand(B, K).reshape(-1)
        k_idx   = disc_b.long().reshape(-1).to(device)
        xk      = cont_b.reshape(-1, 1).to(device)
        loss_r  = hyar_repr.loss(xk, s_rep, k_idx, ns_rep, rxn_idx)
        opt_repr.zero_grad(); loss_r.backward(); opt_repr.step()

    # ── RL training ───────────────────────────────────────────────────────
    history = {
        "state": [], "discrete": [], "continuous": [],
        "reward": [], "raw_reward": [],
        "objective": objective, "media": media, "key_fluxes": [],
    }
    dyn_thr    = 4.0
    lsc_lo     = lsc_hi = None
    total_steps = 0
    done        = False
    best_raw    = -1e9

    # Reset to clean default medium before RL starts
    env.reset_to_default_medium()
    s = env.get_state()

    for ep in range(args.num_episodes):
        if done:
            print(f"  ✓ Converged at episode {ep}")
            break

        if args.curriculum == "rich-to-lean":
            env.set_curriculum_progress(ep / max(args.num_episodes - 1, 1))

        # No per-episode reset — the environment is a continuous task.
        # With disc=0 meaning "reset to default" (not "zero out"), bounds
        # can't get corrupted. Rates accumulate beneficially across episodes,
        # allowing the policy to progressively improve uptake rates.
        # (Per-episode reset was preventing the policy from building up
        # enough flux in just 30 steps to reach the IgG optimum.)
        state_t = _t(s, device).unsqueeze(0)          # (1, state_dim) on device

        for step in range(args.max_steps):

            # ── action selection ──────────────────────────────────────────
            # Epsilon-greedy over discrete: for the first 5 episodes force
            # all reactions active so the policy sees positive IgG signal
            # before learning which ones to remove.
            FORCED_ACTIVE_EPS = 2
            with torch.no_grad():
                disc_t, zx_t, _ = actor.sample(state_t, noise=args.action_noise)
                if ep < FORCED_ACTIVE_EPS:
                    disc_t = torch.ones_like(disc_t)   # force all active
                if lsc_lo is not None:
                    zx_t = apply_lsc(zx_t, lsc_lo, lsc_hi)
                delta_raw = _decode_continuous(hyar_repr, zx_t, state_t, disc_t)

            disc_np = disc_t.cpu().numpy().flatten().astype(int)
            cont_np = delta_raw.cpu().numpy().flatten()
            # Guard: replace any nan/inf in cont with 0 before env.step
            cont_np = np.nan_to_num(cont_np, nan=0.0, posinf=0.0, neginf=0.0)

            # ── env step ──────────────────────────────────────────────────
            ns, reward, info = env.step(disc_np, cont_np)
            raw = info["raw_reward"]
            if raw > best_raw:
                best_raw = raw

            if step % 5 == 0:
                n_tune  = int(disc_np.sum())
                n_reset = K - n_tune
                print(f"    Ep {ep:03d} St {step:02d} | "
                      f"R={reward:+.4f} raw={raw:+.3f} "
                      f"tune={n_tune:2d} reset={n_reset:2d}/{K}")

            history["state"].append(s.tolist())
            history["discrete"].append(disc_np.tolist())
            history["continuous"].append(cont_np.tolist())
            history["reward"].append(float(reward))
            history["raw_reward"].append(float(raw))
            history["key_fluxes"].append(env.get_key_fluxes())

            # convergence check — only converge on a stable POSITIVE reward
            # and only after a minimum number of episodes so the policy has
            # had a chance to explore reaction removal (not just all-active).
            MIN_EPISODES_BEFORE_CONVERGENCE = 10
            recent = history["raw_reward"][-args.patience:]
            if (ep >= MIN_EPISODES_BEFORE_CONVERGENCE
                    and len(recent) == args.patience
                    and len(set(np.round(recent, 6))) == 1
                    and recent[-1] > 0):
                done = True
                break

            # ── store transition on CPU ───────────────────────────────────
            buffer.add((
                _t(s,       "cpu"),
                _t(disc_np, "cpu", dtype=torch.float32),
                _t(cont_np, "cpu"),
                zx_t.squeeze(0).cpu(),           # (K, latent_dim)
                float(reward),
                _t(ns, "cpu"),
            ))

            s = ns
            state_t = _t(s, device).unsqueeze(0)
            total_steps += 1

            # ── TD3 critic + actor update ─────────────────────────────────
            if len(buffer) < args.batch_size:
                continue

            s_b, disc_b, cont_b, zx_b, r_b, ns_b = buffer.sample(args.batch_size)
            # move everything to device in one place
            s_b    = s_b.to(device);    disc_b = disc_b.to(device)
            cont_b = cont_b.to(device); zx_b   = zx_b.to(device)
            r_b    = r_b.to(device);    ns_b   = ns_b.to(device)

            # RSC relabelling
            if args.rsc == "on":
                zx_b = relabel_latent(hyar_repr, s_b, ns_b, disc_b,
                                       cont_b, zx_b, dyn_thr)

            action_b = torch.cat([disc_b, zx_b.flatten(1)], dim=-1)

            with torch.no_grad():
                disc_next, zx_next, _ = actor_target.sample(ns_b, noise=0.0)
                noise = (torch.randn_like(zx_next) * args.action_noise
                         ).clamp(-0.5, 0.5)
                zx_next  = (zx_next + noise).clamp(-1, 1)
                action_next = torch.cat([disc_next, zx_next.flatten(1)], dim=-1)
                q1_t, q2_t = critic_target(ns_b, action_next)
                y = r_b.unsqueeze(1) + args.gamma * torch.min(q1_t, q2_t)

            q1, q2 = critic(s_b, action_b)
            critic_loss = F.mse_loss(q1, y) + F.mse_loss(q2, y)
            opt_critic.zero_grad()
            critic_loss.backward()
            torch.nn.utils.clip_grad_norm_(critic.parameters(), max_norm=1.0)
            opt_critic.step()

            if total_steps % args.policy_delay == 0:
                probs, zx_pi = actor(s_b)
                action_pi    = torch.cat([probs, zx_pi.flatten(1)], dim=-1)
                actor_loss   = -critic.q1_only(s_b, action_pi).mean()
                opt_actor.zero_grad()
                actor_loss.backward()
                torch.nn.utils.clip_grad_norm_(actor.parameters(), max_norm=1.0)
                opt_actor.step()
                soft_update(actor,  actor_target,  args.tau)
                soft_update(critic, critic_target, args.tau)

            # ── representation update ─────────────────────────────────────
            if step % args.repr_train_freq == 0:
                s_r, disc_r, cont_r, _, _, ns_r = buffer.sample(args.repr_batch_size)
                B = s_r.size(0)
                s_rep  = s_r.unsqueeze(1).expand(B, K, -1).reshape(B*K, -1).to(device)
                ns_rep = ns_r.unsqueeze(1).expand(B, K, -1).reshape(B*K, -1).to(device)
                rxn_idx = (torch.arange(K, device=device)
                           .unsqueeze(0).expand(B, K).reshape(-1))
                k_idx  = disc_r.long().reshape(-1).to(device)
                xk     = cont_r.reshape(-1, 1).to(device)
                rl = hyar_repr.loss(xk, s_rep, k_idx, ns_rep, rxn_idx)
                opt_repr.zero_grad()
                rl.backward()
                torch.nn.utils.clip_grad_norm_(hyar_repr.parameters(), max_norm=1.0)
                opt_repr.step()
                dyn_thr = 4.0 * rl.item()

            # ── LSC bounds update ─────────────────────────────────────────
            if total_steps % 50 == 0 and len(buffer) >= args.batch_size * 2:
                _, _, _, zx_s, _, _ = buffer.sample(min(512, len(buffer)))
                # zx_s is CPU tensor from buffer; LSC operates on CPU is fine
                lsc_lo, lsc_hi = compute_lsc_bounds(zx_s, c=args.lsc_percent)

        print(f"  Episode {ep} done | best raw reward: {best_raw:.4f}")

    # ── optimal reference FBA ──────────────────────────────────────────────
    from cobra.io import read_sbml_model
    ref = read_sbml_model(args.xml_path)
    for r in list(ref.medium.keys()):
        ref.reactions.get_by_id(r).lower_bound = -1000
        ref.reactions.get_by_id(r).upper_bound =  1000
    ref.reactions.get_by_id("biomass_cho").lower_bound = max_biomass
    ref.reactions.get_by_id("biomass_cho").upper_bound = max_biomass
    ref.objective = objective
    history["optimal_flux"] = float(ref.optimize()[objective])

    patience = args.patience
    history["final_state"]    = (history["state"][-patience]
                                  if len(history["state"]) >= patience
                                  else history["state"][-1])
    history["final_discrete"] = (history["discrete"][-patience]
                                  if len(history["discrete"]) >= patience
                                  else history["discrete"][-1])

    obj_safe = objective.replace("[", "_").replace("]", "_")
    with open(out_dir / f"history_{obj_safe}.json", "w") as f:
        json.dump(history, f)

    return history
